"""
Experiments for Topological Traps Paper
========================================

Key experiments:
1. Train NSD on organic (Mastodon) data → expect harmonic transport maps
2. Train NSD on algorithmic (Threads) data → expect non-harmonic (rotating) maps
3. Compare polarization dynamics
4. Visualize topological differences

Author: Antonio García
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from pathlib import Path
import json
from tqdm import tqdm
import matplotlib.pyplot as plt

# Local imports
import sys
sys.path.append(str(Path(__file__).parent.parent))

from models.neural_sheaf_diffusion import (
    NeuralSheafDiffusion,
    OrganicSheafDiffusion,
    AlgorithmicSheafDiffusion,
    KuramotoOscillatorGNN
)
from data.data_loaders import (
    SyntheticOpinionGenerator,
    create_dataloaders
)


@dataclass
class ExperimentConfig:
    """Configuration for experiments."""
    
    # Model
    input_dim: int = 10
    hidden_dim: int = 64
    output_dim: int = 10
    stalk_dim: int = 16
    num_layers: int = 5
    num_algo_heads: int = 4
    diffusion_steps: int = 10
    step_size: float = 0.1
    dropout: float = 0.1
    
    # Training
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    num_epochs: int = 100
    batch_size: int = 32
    patience: int = 20
    
    # Data
    num_nodes: int = 500
    num_graphs: int = 200
    opinion_dim: int = 8
    
    # Experiment
    seed: int = 42
    device: str = 'cuda' if torch.cuda.is_available() else 'cpu'
    save_dir: str = './results'
    
    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class Trainer:
    """Trainer for Neural Sheaf Diffusion models."""
    
    def __init__(
        self,
        model: nn.Module,
        config: ExperimentConfig,
        scenario: str = 'organic'
    ):
        self.model = model.to(config.device)
        self.config = config
        self.scenario = scenario
        self.device = config.device
        
        # Optimizer
        self.optimizer = AdamW(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
        
        # Scheduler
        self.scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=config.num_epochs,
            eta_min=1e-6
        )
        
        # Metrics history
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'harmonicity': [],
            'polarization': [],
            'train_polarization': [],
            'val_polarization': []
        }
        
        self.best_val_loss = float('inf')
        self.patience_counter = 0
    
    def compute_loss(
        self,
        output: torch.Tensor,
        target: torch.Tensor,
        maps: Optional[List] = None
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute training loss.
        
        For organic: MSE + orthogonality regularization
        For algorithmic: MSE + engagement proxy
        """
        # Reconstruction loss
        recon_loss = F.mse_loss(output, target)
        
        metrics = {'recon_loss': recon_loss.item()}
        
        # Regularization based on scenario
        if self.scenario == 'organic' and maps is not None:
            # Orthogonality regularization (encourage harmonic transport)
            ortho_loss = self._compute_orthogonality_loss(maps)
            total_loss = recon_loss + 0.1 * ortho_loss
            metrics['ortho_loss'] = ortho_loss.item()
        
        elif self.scenario == 'algorithmic' and maps is not None:
            # No orthogonality constraint (allow non-harmonic)
            # Could add engagement maximization here
            total_loss = recon_loss
        
        else:
            total_loss = recon_loss
        
        metrics['total_loss'] = total_loss.item()
        return total_loss, metrics
    
    def _compute_orthogonality_loss(self, maps: List) -> torch.Tensor:
        """Compute how far transport maps are from orthogonal."""
        losses = []
        
        for maps_list in maps:
            if isinstance(maps_list, list):
                for maps_s, maps_t in maps_list:
                    mtm = torch.bmm(maps_s.transpose(-2, -1), maps_s)
                    identity = torch.eye(
                        maps_s.size(-1),
                        device=maps_s.device
                    ).unsqueeze(0).expand_as(mtm)
                    losses.append(F.mse_loss(mtm, identity))
        
        if losses:
            return torch.stack(losses).mean()
        return torch.tensor(0.0, device=self.device)
    
    def train_epoch(self, train_loader) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        
        total_loss = 0
        total_metrics = {}
        num_batches = 0
        
        for batch in train_loader:
            batch = batch.to(self.device)
            
            self.optimizer.zero_grad()
            
            # Forward pass
            output, trajectory, maps = self.model(
                batch.x, 
                batch.edge_index,
                return_trajectory=True
            )
            
            # Loss
            loss, metrics = self.compute_loss(output, batch.y, maps)
            
            # Backward
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            
            self.optimizer.step()
            
            # Accumulate
            total_loss += loss.item()
            for k, v in metrics.items():
                total_metrics[k] = total_metrics.get(k, 0) + v
            num_batches += 1
        
        # Average
        avg_metrics = {k: v / num_batches for k, v in total_metrics.items()}
        avg_metrics['loss'] = total_loss / num_batches
        
        return avg_metrics
    
    @torch.no_grad()
    def evaluate(self, val_loader) -> Dict[str, float]:
        """Evaluate on validation set."""
        self.model.eval()
        
        total_loss = 0
        total_harmonicity = 0
        total_polarization = 0
        num_batches = 0
        
        for batch in val_loader:
            batch = batch.to(self.device)
            
            output, trajectory, maps = self.model(
                batch.x,
                batch.edge_index,
                return_trajectory=True
            )
            
            # Loss
            loss, _ = self.compute_loss(output, batch.y, maps)
            total_loss += loss.item()
            
            # Harmonicity score
            if maps and hasattr(self.model, 'compute_harmonicity_score'):
                harm = self.model.compute_harmonicity_score(maps[-1])
                total_harmonicity += harm.item()
            
            # Polarization
            if hasattr(self.model, 'compute_polarization_metric'):
                pol = self.model.compute_polarization_metric(output, batch.edge_index)
                total_polarization += pol.item()
            
            num_batches += 1
        
        return {
            'loss': total_loss / num_batches,
            'harmonicity': total_harmonicity / num_batches,
            'polarization': total_polarization / num_batches
        }
    
    def train(
        self,
        train_loader,
        val_loader,
        verbose: bool = True
    ) -> Dict[str, List]:
        """Full training loop."""
        
        pbar = tqdm(range(self.config.num_epochs), disable=not verbose)
        
        for epoch in pbar:
            # Train
            train_metrics = self.train_epoch(train_loader)
            
            # Validate
            val_metrics = self.evaluate(val_loader)
            
            # Update scheduler
            self.scheduler.step()
            
            # Record history
            self.history['train_loss'].append(train_metrics['loss'])
            self.history['val_loss'].append(val_metrics['loss'])
            self.history['harmonicity'].append(val_metrics['harmonicity'])
            self.history['polarization'].append(val_metrics['polarization'])
            
            # Early stopping
            if val_metrics['loss'] < self.best_val_loss:
                self.best_val_loss = val_metrics['loss']
                self.patience_counter = 0
                # Save best model
                self.best_model_state = {
                    k: v.cpu().clone() for k, v in self.model.state_dict().items()
                }
            else:
                self.patience_counter += 1
                if self.patience_counter >= self.config.patience:
                    if verbose:
                        print(f"\nEarly stopping at epoch {epoch}")
                    break
            
            # Progress bar
            pbar.set_description(
                f"Train: {train_metrics['loss']:.4f} | "
                f"Val: {val_metrics['loss']:.4f} | "
                f"Harm: {val_metrics['harmonicity']:.4f}"
            )
        
        # Restore best model
        if hasattr(self, 'best_model_state'):
            self.model.load_state_dict(self.best_model_state)
        
        return self.history


class TopologicalTrapsExperiment:
    """
    Main experiment class comparing organic vs algorithmic scenarios.
    """
    
    def __init__(self, config: ExperimentConfig):
        self.config = config
        self.results = {}
        
        # Set seeds
        torch.manual_seed(config.seed)
        np.random.seed(config.seed)
        
        # Create save directory
        Path(config.save_dir).mkdir(parents=True, exist_ok=True)
    
    def run_organic_experiment(self) -> Dict:
        """
        Experiment 1: Train on organic (Mastodon-like) data.
        
        Expected result: Model learns HARMONIC transport maps
        (close to orthogonal), leading to consensus/low polarization.
        """
        print("\n" + "=" * 60)
        print("EXPERIMENT 1: Organic Platform (Mastodon-like)")
        print("=" * 60)
        
        # Generate organic data
        generator = SyntheticOpinionGenerator(seed=self.config.seed)
        organic_data = generator.generate_dataset(
            num_graphs=self.config.num_graphs,
            num_nodes=self.config.num_nodes,
            scenario='organic',
            opinion_dim=self.config.opinion_dim,
            num_simulation_steps=200,
            confidence_threshold=0.5
        )
        
        # Split data
        n = len(organic_data)
        train_data = organic_data[:int(0.7 * n)]
        val_data = organic_data[int(0.7 * n):int(0.85 * n)]
        test_data = organic_data[int(0.85 * n):]
        
        from torch_geometric.loader import DataLoader
        train_loader = DataLoader(train_data, batch_size=self.config.batch_size, shuffle=True)
        val_loader = DataLoader(val_data, batch_size=self.config.batch_size)
        test_loader = DataLoader(test_data, batch_size=self.config.batch_size)
        
        # Create model
        model = OrganicSheafDiffusion(
            input_dim=self.config.opinion_dim,
            hidden_dim=self.config.hidden_dim,
            output_dim=self.config.opinion_dim,
            stalk_dim=self.config.stalk_dim,
            diffusion_steps=self.config.diffusion_steps,
            dropout=self.config.dropout
        )
        
        print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
        
        # Train
        trainer = Trainer(model, self.config, scenario='organic')
        history = trainer.train(train_loader, val_loader)
        
        # Final evaluation
        test_metrics = trainer.evaluate(test_loader)
        
        results = {
            'history': history,
            'test_metrics': test_metrics,
            'model_state': model.state_dict()
        }
        
        print(f"\nOrganic Results:")
        print(f"  Test Loss: {test_metrics['loss']:.4f}")
        print(f"  Harmonicity: {test_metrics['harmonicity']:.4f} (lower = more harmonic)")
        print(f"  Polarization: {test_metrics['polarization']:.4f}")
        
        self.results['organic'] = results
        return results
    
    def run_algorithmic_experiment(self) -> Dict:
        """
        Experiment 2: Train on algorithmic (Threads-like) data.
        
        Expected result: Model learns NON-HARMONIC transport maps
        (rotations), creating stable polarization states.
        """
        print("\n" + "=" * 60)
        print("EXPERIMENT 2: Algorithmic Platform (Threads-like)")
        print("=" * 60)
        
        # Generate algorithmic data
        generator = SyntheticOpinionGenerator(seed=self.config.seed + 1)
        algo_data = generator.generate_dataset(
            num_graphs=self.config.num_graphs,
            num_nodes=self.config.num_nodes,
            scenario='algorithmic',
            opinion_dim=self.config.opinion_dim,
            num_simulation_steps=200,
            engagement_bias=0.4,
            echo_chamber_strength=0.6
        )
        
        # Split data
        n = len(algo_data)
        train_data = algo_data[:int(0.7 * n)]
        val_data = algo_data[int(0.7 * n):int(0.85 * n)]
        test_data = algo_data[int(0.85 * n):]
        
        from torch_geometric.loader import DataLoader
        train_loader = DataLoader(train_data, batch_size=self.config.batch_size, shuffle=True)
        val_loader = DataLoader(val_data, batch_size=self.config.batch_size)
        test_loader = DataLoader(test_data, batch_size=self.config.batch_size)
        
        # Create model (algorithmic version)
        model = AlgorithmicSheafDiffusion(
            input_dim=self.config.opinion_dim,
            hidden_dim=self.config.hidden_dim,
            output_dim=self.config.opinion_dim,
            stalk_dim=self.config.stalk_dim,
            diffusion_steps=self.config.diffusion_steps,
            num_algo_heads=self.config.num_algo_heads,
            dropout=self.config.dropout
        )
        
        print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
        
        # Train
        trainer = Trainer(model, self.config, scenario='algorithmic')
        history = trainer.train(train_loader, val_loader)
        
        # Final evaluation
        test_metrics = trainer.evaluate(test_loader)
        
        results = {
            'history': history,
            'test_metrics': test_metrics,
            'model_state': model.state_dict()
        }
        
        print(f"\nAlgorithmic Results:")
        print(f"  Test Loss: {test_metrics['loss']:.4f}")
        print(f"  Harmonicity: {test_metrics['harmonicity']:.4f} (higher = more rotation)")
        print(f"  Polarization: {test_metrics['polarization']:.4f}")
        
        self.results['algorithmic'] = results
        return results
    
    def run_kuramoto_baseline(self) -> Dict:
        """
        Baseline: Show that standard Kuramoto model predicts consensus,
        NOT stable polarization.
        """
        print("\n" + "=" * 60)
        print("BASELINE: Kuramoto Oscillator Model")
        print("=" * 60)
        
        # Generate test graph
        generator = SyntheticOpinionGenerator(seed=self.config.seed)
        G = generator.generate_social_graph(
            self.config.num_nodes,
            'barabasi_albert',
            m=5
        )
        
        from torch_geometric.utils import from_networkx
        data = from_networkx(G)
        
        # Kuramoto model
        kuramoto = KuramotoOscillatorGNN(
            num_nodes=self.config.num_nodes,
            coupling_strength=2.0,
            dt=0.01,
            num_steps=500
        )
        
        # Initialize with bimodal distribution (like polarized opinions)
        theta_init = torch.zeros(self.config.num_nodes)
        theta_init[:self.config.num_nodes // 2] = -np.pi / 2
        theta_init[self.config.num_nodes // 2:] = np.pi / 2
        theta_init += torch.randn_like(theta_init) * 0.3
        
        # Simulate
        theta_final, trajectory = kuramoto(
            theta_init,
            data.edge_index,
            return_trajectory=True
        )
        
        # Compute order parameter over time
        order_params = []
        for theta in trajectory[::10]:  # Sample every 10 steps
            r = kuramoto.compute_order_parameter(theta)
            order_params.append(r.item())
        
        results = {
            'initial_order': order_params[0],
            'final_order': order_params[-1],
            'order_trajectory': order_params
        }
        
        print(f"\nKuramoto Results:")
        print(f"  Initial order parameter: {order_params[0]:.4f}")
        print(f"  Final order parameter: {order_params[-1]:.4f}")
        print(f"  Interpretation: Order → 1 means SYNCHRONIZATION (consensus)")
        print(f"                  Kuramoto CANNOT maintain stable polarization!")
        
        self.results['kuramoto'] = results
        return results
    
    def run_all_experiments(self) -> Dict:
        """Run all experiments and compare."""
        
        organic = self.run_organic_experiment()
        algorithmic = self.run_algorithmic_experiment()
        kuramoto = self.run_kuramoto_baseline()
        
        # Summary comparison
        print("\n" + "=" * 60)
        print("SUMMARY: Organic vs Algorithmic Platforms")
        print("=" * 60)
        
        print(f"\n{'Metric':<25} {'Organic':<15} {'Algorithmic':<15}")
        print("-" * 55)
        
        print(f"{'Final Test Loss':<25} "
              f"{organic['test_metrics']['loss']:<15.4f} "
              f"{algorithmic['test_metrics']['loss']:<15.4f}")
        
        print(f"{'Harmonicity Score':<25} "
              f"{organic['test_metrics']['harmonicity']:<15.4f} "
              f"{algorithmic['test_metrics']['harmonicity']:<15.4f}")
        
        print(f"{'Polarization':<25} "
              f"{organic['test_metrics']['polarization']:<15.4f} "
              f"{algorithmic['test_metrics']['polarization']:<15.4f}")
        
        print("\n" + "=" * 60)
        print("KEY FINDINGS:")
        print("=" * 60)
        
        harm_diff = algorithmic['test_metrics']['harmonicity'] - organic['test_metrics']['harmonicity']
        pol_diff = algorithmic['test_metrics']['polarization'] - organic['test_metrics']['polarization']
        
        print(f"\n1. Harmonicity difference: {harm_diff:+.4f}")
        if harm_diff > 0:
            print("   → Algorithmic platform learns MORE ROTATIONAL transport maps")
            print("   → This creates 'topological traps' that prevent consensus")
        
        print(f"\n2. Polarization difference: {pol_diff:+.4f}")
        if pol_diff > 0:
            print("   → Algorithmic platform produces MORE POLARIZATION")
            print("   → Confirms hypothesis that algorithms actively create discord")
        
        print(f"\n3. Kuramoto baseline shows synchronization (r → {kuramoto['final_order']:.2f})")
        print("   → Standard physics models predict CONSENSUS")
        print("   → Our sheaf model captures what Kuramoto cannot!")
        
        # Save results
        self._save_results()
        
        return self.results
    
    def _save_results(self):
        """Save experiment results."""
        save_path = Path(self.config.save_dir)
        
        # Save summary
        summary = {
            'config': self.config.to_dict(),
            'organic_metrics': self.results.get('organic', {}).get('test_metrics', {}),
            'algorithmic_metrics': self.results.get('algorithmic', {}).get('test_metrics', {}),
            'kuramoto': self.results.get('kuramoto', {})
        }
        
        with open(save_path / 'experiment_summary.json', 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        
        print(f"\nResults saved to {save_path}")


def run_quick_demo():
    """Quick demonstration with smaller parameters."""
    
    config = ExperimentConfig(
        num_nodes=100,
        num_graphs=50,
        num_epochs=30,
        batch_size=8,
        hidden_dim=32,
        stalk_dim=8,
        diffusion_steps=5
    )
    
    experiment = TopologicalTrapsExperiment(config)
    results = experiment.run_all_experiments()
    
    return results


if __name__ == "__main__":
    print("=" * 60)
    print("Topological Traps: Neural Sheaf Diffusion Experiments")
    print("=" * 60)
    
    # Run quick demo
    results = run_quick_demo()
