"""
Topological Traps: Modeling Algorithmic Polarization via Neural Sheaf Diffusion
================================================================================

Main entry point for running experiments.

Paper: "Topological Traps: Modeling Algorithmic Polarization via Neural Sheaf 
        Diffusion in Federated Networks"

Usage:
    python main.py --mode train --scenario both
    python main.py --mode visualize
    python main.py --mode demo

Author: Antonio García
"""

import argparse
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

import torch
import numpy as np


def run_training(config_overrides: dict = None):
    """Run full training experiments."""
    from experiments.train_experiments import TopologicalTrapsExperiment, ExperimentConfig
    
    config = ExperimentConfig()
    
    # Apply overrides
    if config_overrides:
        for k, v in config_overrides.items():
            if hasattr(config, k):
                setattr(config, k, v)
    
    experiment = TopologicalTrapsExperiment(config)
    results = experiment.run_all_experiments()
    
    return results


def run_demo():
    """Run quick demonstration."""
    from experiments.train_experiments import run_quick_demo
    
    print("=" * 60)
    print("TOPOLOGICAL TRAPS - QUICK DEMO")
    print("=" * 60)
    print("\nThis demo shows the key finding:")
    print("  • Organic platforms → harmonic transport → consensus")
    print("  • Algorithmic platforms → rotational transport → polarization")
    print()
    
    results = run_quick_demo()
    return results


def run_visualization():
    """Generate all paper figures."""
    from visualizations.visualize import generate_all_figures, SheafVisualizer
    
    print("=" * 60)
    print("GENERATING PAPER FIGURES")
    print("=" * 60)
    
    generate_all_figures()


def run_metrics_analysis():
    """Run metrics analysis on sample data."""
    from utils.metrics import compute_all_metrics
    from data.data_loaders import SyntheticOpinionGenerator
    from torch_geometric.utils import from_networkx
    
    print("=" * 60)
    print("METRICS ANALYSIS")
    print("=" * 60)
    
    generator = SyntheticOpinionGenerator(seed=42)
    
    # Generate organic scenario
    print("\n1. Organic Platform Metrics:")
    G_org = generator.generate_social_graph(200, 'barabasi_albert', m=5)
    opinions_org = generator.initialize_opinions(200, 8, 'uniform')
    traj_org = generator.simulate_organic_dynamics(G_org, opinions_org, 100)
    
    data_org = from_networkx(G_org)
    opinions_tensor = torch.tensor(traj_org[-1], dtype=torch.float)
    
    metrics_org = compute_all_metrics(
        opinions_tensor, 
        data_org.edge_index,
        trajectory=[torch.tensor(t) for t in traj_org]
    )
    
    for k, v in sorted(metrics_org.items())[:10]:
        print(f"  {k}: {v:.4f}")
    
    # Generate algorithmic scenario
    print("\n2. Algorithmic Platform Metrics:")
    G_algo = generator.generate_social_graph(200, 'barabasi_albert', m=5)
    opinions_algo = generator.initialize_opinions(200, 8, 'bimodal')
    traj_algo = generator.simulate_algorithmic_dynamics(G_algo, opinions_algo, 100)
    
    data_algo = from_networkx(G_algo)
    opinions_tensor = torch.tensor(traj_algo[-1], dtype=torch.float)
    
    metrics_algo = compute_all_metrics(
        opinions_tensor,
        data_algo.edge_index,
        trajectory=[torch.tensor(t) for t in traj_algo]
    )
    
    for k, v in sorted(metrics_algo.items())[:10]:
        print(f"  {k}: {v:.4f}")
    
    # Comparison
    print("\n" + "=" * 60)
    print("KEY DIFFERENCES:")
    print("=" * 60)
    print(f"  Polarization: Organic={metrics_org['variance_polarization']:.4f} "
          f"vs Algo={metrics_algo['variance_polarization']:.4f}")
    print(f"  Disagreement: Organic={metrics_org['edge_mean_disagreement']:.4f} "
          f"vs Algo={metrics_algo['edge_mean_disagreement']:.4f}")


def test_models():
    """Test model implementations."""
    print("=" * 60)
    print("TESTING MODEL IMPLEMENTATIONS")
    print("=" * 60)
    
    from models.neural_sheaf_diffusion import (
        NeuralSheafDiffusion,
        OrganicSheafDiffusion,
        AlgorithmicSheafDiffusion,
        KuramotoOscillatorGNN
    )
    
    # Test data
    num_nodes = 100
    input_dim = 8
    x = torch.randn(num_nodes, input_dim)
    edge_index = torch.randint(0, num_nodes, (2, 500))
    
    print("\n1. Testing NeuralSheafDiffusion...")
    model = NeuralSheafDiffusion(
        input_dim=input_dim,
        hidden_dim=32,
        output_dim=input_dim,
        stalk_dim=8,
        diffusion_steps=5
    )
    out, traj, maps = model(x, edge_index, return_trajectory=True)
    print(f"   Output shape: {out.shape}")
    print(f"   Trajectory length: {len(traj)}")
    print("   ✓ Passed")
    
    print("\n2. Testing OrganicSheafDiffusion...")
    model_org = OrganicSheafDiffusion(
        input_dim=input_dim,
        hidden_dim=32,
        output_dim=input_dim,
        stalk_dim=8,
        diffusion_steps=5
    )
    out, _, maps = model_org(x, edge_index, return_trajectory=True)
    if maps:
        harm = model_org.compute_harmonicity_score(maps[-1])
        print(f"   Harmonicity score: {harm.item():.4f}")
    print("   ✓ Passed")
    
    print("\n3. Testing AlgorithmicSheafDiffusion...")
    model_algo = AlgorithmicSheafDiffusion(
        input_dim=input_dim,
        hidden_dim=32,
        output_dim=input_dim,
        stalk_dim=8,
        diffusion_steps=5,
        num_algo_heads=2
    )
    out, _, maps = model_algo(x, edge_index, return_trajectory=True)
    if maps:
        harm = model_algo.compute_harmonicity_score(maps[-1])
        print(f"   Harmonicity score: {harm.item():.4f}")
    print("   ✓ Passed")
    
    print("\n4. Testing KuramotoOscillatorGNN...")
    kuramoto = KuramotoOscillatorGNN(num_nodes=num_nodes, num_steps=50)
    theta_init = torch.randn(num_nodes)
    theta_final, traj = kuramoto(theta_init, edge_index, return_trajectory=True)
    r = kuramoto.compute_order_parameter(theta_final)
    print(f"   Final order parameter: {r.item():.4f}")
    print("   ✓ Passed")
    
    print("\n" + "=" * 60)
    print("ALL MODEL TESTS PASSED!")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description='Topological Traps: Neural Sheaf Diffusion for Polarization'
    )
    
    parser.add_argument(
        '--mode', 
        type=str, 
        default='demo',
        choices=['train', 'demo', 'visualize', 'metrics', 'test'],
        help='Mode to run'
    )
    
    parser.add_argument(
        '--scenario',
        type=str,
        default='both',
        choices=['organic', 'algorithmic', 'both'],
        help='Which scenario to train'
    )
    
    parser.add_argument('--num_epochs', type=int, default=100)
    parser.add_argument('--num_nodes', type=int, default=500)
    parser.add_argument('--num_graphs', type=int, default=200)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--hidden_dim', type=int, default=64)
    parser.add_argument('--stalk_dim', type=int, default=16)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--device', type=str, default='auto')
    
    args = parser.parse_args()
    
    # Set device
    if args.device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    else:
        device = args.device
    
    print(f"\nUsing device: {device}")
    
    # Run appropriate mode
    if args.mode == 'train':
        config_overrides = {
            'num_epochs': args.num_epochs,
            'num_nodes': args.num_nodes,
            'num_graphs': args.num_graphs,
            'batch_size': args.batch_size,
            'hidden_dim': args.hidden_dim,
            'stalk_dim': args.stalk_dim,
            'seed': args.seed,
            'device': device
        }
        run_training(config_overrides)
    
    elif args.mode == 'demo':
        run_demo()
    
    elif args.mode == 'visualize':
        run_visualization()
    
    elif args.mode == 'metrics':
        run_metrics_analysis()
    
    elif args.mode == 'test':
        test_models()


if __name__ == "__main__":
    main()
