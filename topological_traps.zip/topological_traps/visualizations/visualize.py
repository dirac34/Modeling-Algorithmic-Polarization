"""
Visualization Tools for Topological Traps Paper
================================================

Includes:
1. Transport map visualization (showing rotations)
2. Opinion dynamics trajectories
3. Polarization heatmaps
4. Sheaf cohomology visualization
5. Publication-ready figures

Author: Antonio García
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.mplot3d import Axes3D
import networkx as nx
from typing import List, Dict, Optional, Tuple
from pathlib import Path


# Custom colormap for polarization
POLARIZATION_CMAP = LinearSegmentedColormap.from_list(
    'polarization',
    ['#2166ac', '#f7f7f7', '#b2182b']  # Blue (left) - White - Red (right)
)


class SheafVisualizer:
    """Visualization tools for sheaf-based analysis."""
    
    def __init__(self, save_dir: str = './figures', style: str = 'paper'):
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        # Set style
        if style == 'paper':
            plt.style.use('seaborn-v0_8-whitegrid')
            plt.rcParams.update({
                'font.size': 12,
                'axes.labelsize': 14,
                'axes.titlesize': 14,
                'xtick.labelsize': 11,
                'ytick.labelsize': 11,
                'legend.fontsize': 11,
                'figure.figsize': (8, 6),
                'figure.dpi': 150,
                'savefig.dpi': 300,
                'savefig.bbox': 'tight'
            })
    
    def visualize_transport_maps(
        self,
        maps_organic: torch.Tensor,
        maps_algorithmic: torch.Tensor,
        num_samples: int = 5,
        save_name: str = 'transport_maps_comparison.pdf'
    ):
        """
        Visualize learned transport maps comparing organic vs algorithmic.
        
        For 2D case: show as vector fields
        For higher D: show singular value spectrum
        """
        fig, axes = plt.subplots(2, num_samples, figsize=(4 * num_samples, 8))
        
        # Sample random maps
        n_maps = min(maps_organic.size(0), num_samples)
        indices = np.random.choice(maps_organic.size(0), n_maps, replace=False)
        
        for i, idx in enumerate(indices):
            # Organic
            M_org = maps_organic[idx].detach().cpu().numpy()
            ax = axes[0, i]
            
            # Compute SVD
            U, S, Vh = np.linalg.svd(M_org)
            
            # Visualize as ellipse transformation
            theta = np.linspace(0, 2 * np.pi, 100)
            circle = np.array([np.cos(theta), np.sin(theta)])
            
            # For 2D projection
            if M_org.shape[0] >= 2:
                M_2d = M_org[:2, :2]
                ellipse = M_2d @ circle[:2]
                
                ax.plot(circle[0], circle[1], 'b--', alpha=0.5, label='Unit circle')
                ax.plot(ellipse[0], ellipse[1], 'g-', linewidth=2, label='Transformed')
                ax.set_xlim(-2, 2)
                ax.set_ylim(-2, 2)
                ax.set_aspect('equal')
                ax.axhline(y=0, color='k', linewidth=0.5)
                ax.axvline(x=0, color='k', linewidth=0.5)
            
            # Show singular values
            ax.set_title(f'Organic #{i+1}\nσ = [{S[0]:.2f}, {S[1]:.2f}, ...]')
            if i == 0:
                ax.set_ylabel('Organic\n(Harmonic)')
                ax.legend(loc='upper right', fontsize=8)
            
            # Algorithmic
            M_algo = maps_algorithmic[idx].detach().cpu().numpy()
            ax = axes[1, i]
            
            U, S, Vh = np.linalg.svd(M_algo)
            
            if M_algo.shape[0] >= 2:
                M_2d = M_algo[:2, :2]
                ellipse = M_2d @ circle[:2]
                
                ax.plot(circle[0], circle[1], 'b--', alpha=0.5)
                ax.plot(ellipse[0], ellipse[1], 'r-', linewidth=2)
                ax.set_xlim(-2, 2)
                ax.set_ylim(-2, 2)
                ax.set_aspect('equal')
                ax.axhline(y=0, color='k', linewidth=0.5)
                ax.axvline(x=0, color='k', linewidth=0.5)
            
            ax.set_title(f'Algorithmic #{i+1}\nσ = [{S[0]:.2f}, {S[1]:.2f}, ...]')
            if i == 0:
                ax.set_ylabel('Algorithmic\n(Non-harmonic)')
        
        plt.suptitle('Transport Map Comparison: Organic vs Algorithmic Platforms', 
                     fontsize=16, y=1.02)
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
    
    def visualize_singular_value_spectrum(
        self,
        maps_organic: torch.Tensor,
        maps_algorithmic: torch.Tensor,
        save_name: str = 'singular_value_spectrum.pdf'
    ):
        """
        Compare singular value spectra of transport maps.
        
        Harmonic maps should have σ ≈ 1 (orthogonal)
        Non-harmonic should have varying σ (rotations + scaling)
        """
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Compute SVD for all maps
        def get_singular_values(maps):
            svs = []
            for M in maps:
                M_np = M.detach().cpu().numpy()
                _, S, _ = np.linalg.svd(M_np)
                svs.append(S)
            return np.array(svs)
        
        sv_organic = get_singular_values(maps_organic)
        sv_algo = get_singular_values(maps_algorithmic)
        
        # Plot distributions
        ax = axes[0]
        ax.hist(sv_organic.flatten(), bins=50, alpha=0.7, color='green', 
                label='Organic', density=True)
        ax.hist(sv_algo.flatten(), bins=50, alpha=0.7, color='red',
                label='Algorithmic', density=True)
        ax.axvline(x=1.0, color='black', linestyle='--', label='Orthogonal (σ=1)')
        ax.set_xlabel('Singular Value')
        ax.set_ylabel('Density')
        ax.set_title('Singular Value Distribution')
        ax.legend()
        
        # Plot mean ± std per component
        ax = axes[1]
        n_components = min(sv_organic.shape[1], 10)
        x = np.arange(n_components)
        
        mean_org = sv_organic[:, :n_components].mean(axis=0)
        std_org = sv_organic[:, :n_components].std(axis=0)
        mean_algo = sv_algo[:, :n_components].mean(axis=0)
        std_algo = sv_algo[:, :n_components].std(axis=0)
        
        ax.errorbar(x - 0.1, mean_org, yerr=std_org, fmt='o-', color='green',
                   label='Organic', capsize=3)
        ax.errorbar(x + 0.1, mean_algo, yerr=std_algo, fmt='s-', color='red',
                   label='Algorithmic', capsize=3)
        ax.axhline(y=1.0, color='black', linestyle='--', alpha=0.5)
        ax.set_xlabel('Singular Value Index')
        ax.set_ylabel('Value')
        ax.set_title('Singular Values by Component')
        ax.legend()
        ax.set_xticks(x)
        
        plt.suptitle('Sheaf Transport Map Analysis', fontsize=14, y=1.02)
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
    
    def visualize_opinion_trajectory(
        self,
        trajectory_organic: List[torch.Tensor],
        trajectory_algorithmic: List[torch.Tensor],
        save_name: str = 'opinion_trajectories.pdf'
    ):
        """
        Visualize opinion evolution over time.
        """
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        
        def get_opinion_stats(trajectory):
            means = []
            stds = []
            polarizations = []
            
            for t in trajectory:
                t_np = t.detach().cpu().numpy() if torch.is_tensor(t) else t
                means.append(t_np.mean())
                stds.append(t_np.std())
                # Polarization: bimodality measure
                polarizations.append(np.var(t_np))
            
            return np.array(means), np.array(stds), np.array(polarizations)
        
        mean_org, std_org, pol_org = get_opinion_stats(trajectory_organic)
        mean_algo, std_algo, pol_algo = get_opinion_stats(trajectory_algorithmic)
        
        time_org = np.arange(len(trajectory_organic))
        time_algo = np.arange(len(trajectory_algorithmic))
        
        # Mean opinion
        axes[0, 0].plot(time_org, mean_org, 'g-', label='Organic', linewidth=2)
        axes[0, 0].plot(time_algo, mean_algo, 'r-', label='Algorithmic', linewidth=2)
        axes[0, 0].set_xlabel('Time Step')
        axes[0, 0].set_ylabel('Mean Opinion')
        axes[0, 0].set_title('Mean Opinion Over Time')
        axes[0, 0].legend()
        
        # Standard deviation
        axes[0, 1].plot(time_org, std_org, 'g-', label='Organic', linewidth=2)
        axes[0, 1].plot(time_algo, std_algo, 'r-', label='Algorithmic', linewidth=2)
        axes[0, 1].set_xlabel('Time Step')
        axes[0, 1].set_ylabel('Std Dev')
        axes[0, 1].set_title('Opinion Spread Over Time')
        axes[0, 1].legend()
        
        # Polarization
        axes[0, 2].plot(time_org, pol_org, 'g-', label='Organic', linewidth=2)
        axes[0, 2].plot(time_algo, pol_algo, 'r-', label='Algorithmic', linewidth=2)
        axes[0, 2].set_xlabel('Time Step')
        axes[0, 2].set_ylabel('Variance')
        axes[0, 2].set_title('Polarization Over Time')
        axes[0, 2].legend()
        
        # Opinion distributions at different times
        def plot_distribution(ax, trajectory, times, title, color):
            for i, t_idx in enumerate(times):
                if t_idx < len(trajectory):
                    t_np = trajectory[t_idx]
                    if torch.is_tensor(t_np):
                        t_np = t_np.detach().cpu().numpy()
                    ax.hist(t_np.flatten(), bins=30, alpha=0.5, 
                           label=f't={t_idx}', color=plt.cm.viridis(i/len(times)))
            ax.set_xlabel('Opinion Value')
            ax.set_ylabel('Count')
            ax.set_title(title)
            ax.legend(fontsize=8)
        
        times = [0, len(trajectory_organic) // 2, len(trajectory_organic) - 1]
        plot_distribution(axes[1, 0], trajectory_organic, times, 
                         'Organic: Opinion Distributions', 'green')
        
        times = [0, len(trajectory_algorithmic) // 2, len(trajectory_algorithmic) - 1]
        plot_distribution(axes[1, 1], trajectory_algorithmic, times,
                         'Algorithmic: Opinion Distributions', 'red')
        
        # Final state comparison
        final_org = trajectory_organic[-1]
        final_algo = trajectory_algorithmic[-1]
        if torch.is_tensor(final_org):
            final_org = final_org.detach().cpu().numpy()
        if torch.is_tensor(final_algo):
            final_algo = final_algo.detach().cpu().numpy()
        
        axes[1, 2].hist(final_org.flatten(), bins=30, alpha=0.6, 
                       label='Organic', color='green')
        axes[1, 2].hist(final_algo.flatten(), bins=30, alpha=0.6,
                       label='Algorithmic', color='red')
        axes[1, 2].set_xlabel('Opinion Value')
        axes[1, 2].set_ylabel('Count')
        axes[1, 2].set_title('Final State Comparison')
        axes[1, 2].legend()
        
        plt.suptitle('Opinion Dynamics: Organic vs Algorithmic', fontsize=14, y=1.02)
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
    
    def visualize_graph_with_opinions(
        self,
        edge_index: torch.Tensor,
        opinions: torch.Tensor,
        title: str = 'Opinion Graph',
        save_name: str = 'opinion_graph.pdf'
    ):
        """
        Visualize graph with nodes colored by opinion.
        """
        # Convert to networkx
        edge_list = edge_index.t().cpu().numpy()
        G = nx.Graph()
        G.add_edges_from(edge_list)
        
        # Get opinion values (first dimension)
        if torch.is_tensor(opinions):
            opinions = opinions.detach().cpu().numpy()
        if len(opinions.shape) > 1:
            opinions = opinions[:, 0]
        
        # Layout
        pos = nx.spring_layout(G, seed=42, k=2/np.sqrt(G.number_of_nodes()))
        
        # Create figure
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Draw edges
        nx.draw_networkx_edges(G, pos, alpha=0.2, ax=ax)
        
        # Draw nodes with opinion colors
        nodes = nx.draw_networkx_nodes(
            G, pos,
            node_color=opinions,
            cmap=POLARIZATION_CMAP,
            vmin=-1, vmax=1,
            node_size=50,
            ax=ax
        )
        
        # Colorbar
        plt.colorbar(nodes, ax=ax, label='Opinion')
        
        ax.set_title(title, fontsize=14)
        ax.axis('off')
        
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
    
    def visualize_training_curves(
        self,
        history_organic: Dict[str, List],
        history_algorithmic: Dict[str, List],
        save_name: str = 'training_curves.pdf'
    ):
        """
        Plot training curves for both scenarios.
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Loss
        ax = axes[0, 0]
        ax.plot(history_organic['train_loss'], 'g-', label='Organic Train', alpha=0.7)
        ax.plot(history_organic['val_loss'], 'g--', label='Organic Val', linewidth=2)
        ax.plot(history_algorithmic['train_loss'], 'r-', label='Algo Train', alpha=0.7)
        ax.plot(history_algorithmic['val_loss'], 'r--', label='Algo Val', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Training Loss')
        ax.legend()
        ax.set_yscale('log')
        
        # Harmonicity
        ax = axes[0, 1]
        ax.plot(history_organic['harmonicity'], 'g-', label='Organic', linewidth=2)
        ax.plot(history_algorithmic['harmonicity'], 'r-', label='Algorithmic', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Harmonicity Score')
        ax.set_title('Transport Map Harmonicity')
        ax.legend()
        
        # Polarization
        ax = axes[1, 0]
        ax.plot(history_organic['polarization'], 'g-', label='Organic', linewidth=2)
        ax.plot(history_algorithmic['polarization'], 'r-', label='Algorithmic', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Polarization')
        ax.set_title('Output Polarization')
        ax.legend()
        
        # Harmonicity vs Polarization scatter
        ax = axes[1, 1]
        ax.scatter(history_organic['harmonicity'], history_organic['polarization'],
                  c=range(len(history_organic['harmonicity'])), cmap='Greens',
                  label='Organic', alpha=0.7)
        ax.scatter(history_algorithmic['harmonicity'], history_algorithmic['polarization'],
                  c=range(len(history_algorithmic['harmonicity'])), cmap='Reds',
                  label='Algorithmic', alpha=0.7)
        ax.set_xlabel('Harmonicity')
        ax.set_ylabel('Polarization')
        ax.set_title('Harmonicity vs Polarization')
        ax.legend()
        
        plt.suptitle('Training Progress: Organic vs Algorithmic', fontsize=14, y=1.02)
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
    
    def create_paper_figure_1(
        self,
        save_name: str = 'figure1_concept.pdf'
    ):
        """
        Create conceptual Figure 1 for the paper.
        
        Shows the key idea: algorithms create "topological traps" through
        non-orthogonal transport maps.
        """
        fig = plt.figure(figsize=(14, 5))
        
        # Left: Organic (Mastodon) - harmonic diffusion
        ax1 = fig.add_subplot(131)
        
        # Create a simple graph visualization
        G = nx.karate_club_graph()
        pos = nx.spring_layout(G, seed=42)
        
        # Opinions converging
        opinions = np.random.randn(len(G.nodes))
        opinions = opinions * 0.3  # Low variance = consensus
        
        nx.draw_networkx_edges(G, pos, alpha=0.3, ax=ax1)
        nodes = nx.draw_networkx_nodes(G, pos, node_color=opinions,
                                       cmap=POLARIZATION_CMAP, vmin=-1, vmax=1,
                                       node_size=100, ax=ax1)
        ax1.set_title('Organic Platform\n(Harmonic Diffusion → Consensus)', fontsize=12)
        ax1.axis('off')
        
        # Middle: Transport maps comparison
        ax2 = fig.add_subplot(132)
        
        theta = np.linspace(0, 2 * np.pi, 100)
        circle = np.array([np.cos(theta), np.sin(theta)])
        
        # Orthogonal (organic)
        M_ortho = np.array([[0.9, -0.1], [0.1, 0.9]])  # Near identity
        ellipse_ortho = M_ortho @ circle
        ax2.plot(ellipse_ortho[0], ellipse_ortho[1], 'g-', linewidth=3,
                label='Organic (≈ orthogonal)')
        
        # Rotational (algorithmic)
        M_rot = np.array([[1.3, -0.8], [0.5, 0.7]])  # Rotation + scaling
        ellipse_rot = M_rot @ circle
        ax2.plot(ellipse_rot[0], ellipse_rot[1], 'r-', linewidth=3,
                label='Algorithmic (rotation)')
        
        ax2.plot(circle[0], circle[1], 'k--', alpha=0.5, label='Identity')
        ax2.set_xlim(-2, 2)
        ax2.set_ylim(-2, 2)
        ax2.set_aspect('equal')
        ax2.axhline(y=0, color='k', linewidth=0.5)
        ax2.axvline(x=0, color='k', linewidth=0.5)
        ax2.legend(loc='upper right', fontsize=9)
        ax2.set_title('Transport Maps\n(Learned Sheaf Structure)', fontsize=12)
        
        # Right: Algorithmic (Threads) - trapped polarization
        ax3 = fig.add_subplot(133)
        
        # Opinions polarized
        opinions_pol = np.zeros(len(G.nodes))
        opinions_pol[:len(G.nodes)//2] = -0.8 + np.random.randn(len(G.nodes)//2) * 0.1
        opinions_pol[len(G.nodes)//2:] = 0.8 + np.random.randn(len(G.nodes) - len(G.nodes)//2) * 0.1
        
        nx.draw_networkx_edges(G, pos, alpha=0.3, ax=ax3)
        nodes = nx.draw_networkx_nodes(G, pos, node_color=opinions_pol,
                                       cmap=POLARIZATION_CMAP, vmin=-1, vmax=1,
                                       node_size=100, ax=ax3)
        ax3.set_title('Algorithmic Platform\n(Topological Trap → Polarization)', fontsize=12)
        ax3.axis('off')
        
        plt.suptitle('Topological Traps: How Algorithms Create Stable Polarization',
                    fontsize=14, fontweight='bold', y=1.05)
        
        plt.tight_layout()
        plt.savefig(self.save_dir / save_name)
        plt.close()
        
        print(f"Saved: {self.save_dir / save_name}")
        print("\nThis figure illustrates the paper's core thesis:")
        print("  - Organic platforms → harmonic transport → consensus")
        print("  - Algorithmic platforms → rotational transport → polarization traps")


def generate_all_figures():
    """Generate all figures for the paper."""
    
    viz = SheafVisualizer(save_dir='./figures')
    
    # Figure 1: Concept
    viz.create_paper_figure_1()
    
    print("\n" + "=" * 60)
    print("Figures generated in ./figures/")
    print("=" * 60)


if __name__ == "__main__":
    generate_all_figures()
