"""
Metrics for Topological Traps Analysis
======================================

Includes:
1. Polarization measures
2. Harmonicity (sheaf cohomology-inspired)
3. Synchronization metrics (Kuramoto order parameter)
4. Graph-based opinion metrics

Author: Antonio García
"""

import torch
import numpy as np
from typing import Dict, List, Tuple, Optional
from scipy import stats
from scipy.spatial.distance import pdist, squareform
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score


class PolarizationMetrics:
    """
    Metrics for measuring opinion polarization in networks.
    """
    
    @staticmethod
    def variance_polarization(opinions: torch.Tensor) -> torch.Tensor:
        """
        Simple variance-based polarization.
        Higher variance = more polarized.
        """
        if torch.is_tensor(opinions):
            return opinions.var()
        return torch.tensor(np.var(opinions))
    
    @staticmethod
    def bimodality_coefficient(opinions: torch.Tensor) -> float:
        """
        Bimodality coefficient: BC = (skewness² + 1) / kurtosis
        
        BC > 0.555 suggests bimodal distribution (polarization)
        """
        if torch.is_tensor(opinions):
            opinions = opinions.detach().cpu().numpy()
        
        opinions = opinions.flatten()
        n = len(opinions)
        
        # Skewness
        mean = np.mean(opinions)
        std = np.std(opinions)
        skewness = np.mean(((opinions - mean) / std) ** 3)
        
        # Kurtosis (excess)
        kurtosis = np.mean(((opinions - mean) / std) ** 4) - 3
        
        # Bimodality coefficient
        bc = (skewness ** 2 + 1) / (kurtosis + 3 * (n - 1) ** 2 / ((n - 2) * (n - 3)))
        
        return bc
    
    @staticmethod
    def dip_test_statistic(opinions: torch.Tensor) -> Tuple[float, float]:
        """
        Hartigan's dip test for unimodality.
        Low p-value suggests multimodality (polarization).
        
        Returns: (dip_statistic, p_value)
        """
        if torch.is_tensor(opinions):
            opinions = opinions.detach().cpu().numpy()
        
        opinions = np.sort(opinions.flatten())
        n = len(opinions)
        
        # Compute empirical distribution
        empirical = np.arange(1, n + 1) / n
        
        # Find greatest convex minorant and least concave majorant
        # (Simplified implementation)
        dip = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                # Linear interpolation
                slope = (empirical[j] - empirical[i]) / (opinions[j] - opinions[i] + 1e-10)
                
                for k in range(i, j + 1):
                    expected = empirical[i] + slope * (opinions[k] - opinions[i])
                    dip = max(dip, abs(empirical[k] - expected))
        
        # Approximate p-value (simplified)
        p_value = np.exp(-2 * n * dip ** 2)
        
        return dip, p_value
    
    @staticmethod
    def cluster_polarization(
        opinions: torch.Tensor,
        n_clusters: int = 2
    ) -> Dict[str, float]:
        """
        Measure polarization via clustering quality.
        
        High silhouette score with 2 clusters = strong polarization
        """
        if torch.is_tensor(opinions):
            opinions = opinions.detach().cpu().numpy()
        
        if len(opinions.shape) == 1:
            opinions = opinions.reshape(-1, 1)
        
        # K-means clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(opinions)
        
        # Silhouette score
        if len(np.unique(labels)) > 1:
            silhouette = silhouette_score(opinions, labels)
        else:
            silhouette = 0.0
        
        # Cluster separation (distance between centroids)
        centroids = kmeans.cluster_centers_
        if len(centroids) >= 2:
            separation = np.linalg.norm(centroids[0] - centroids[1])
        else:
            separation = 0.0
        
        # Cluster sizes (balance)
        unique, counts = np.unique(labels, return_counts=True)
        balance = min(counts) / max(counts) if len(counts) > 1 else 1.0
        
        return {
            'silhouette': silhouette,
            'separation': separation,
            'balance': balance,
            'polarization_score': silhouette * separation * balance
        }
    
    @staticmethod
    def edge_disagreement(
        opinions: torch.Tensor,
        edge_index: torch.Tensor
    ) -> Dict[str, float]:
        """
        Measure opinion disagreement along graph edges.
        
        High edge disagreement = opinions differ between connected nodes
        """
        if torch.is_tensor(opinions):
            opinions_np = opinions.detach().cpu().numpy()
        else:
            opinions_np = opinions
        
        row, col = edge_index[0].cpu().numpy(), edge_index[1].cpu().numpy()
        
        # Opinion differences along edges
        diffs = opinions_np[row] - opinions_np[col]
        if len(diffs.shape) > 1:
            diffs = np.linalg.norm(diffs, axis=1)
        
        return {
            'mean_disagreement': np.mean(np.abs(diffs)),
            'max_disagreement': np.max(np.abs(diffs)),
            'std_disagreement': np.std(np.abs(diffs)),
            'disagreement_variance': np.var(diffs)
        }


class HarmonicityMetrics:
    """
    Metrics for measuring harmonicity of sheaf transport maps.
    
    Harmonic = orthogonal transforms (preserve Euclidean structure)
    Non-harmonic = rotations/shears (distort structure, create "traps")
    """
    
    @staticmethod
    def orthogonality_deviation(maps: torch.Tensor) -> torch.Tensor:
        """
        Measure deviation from orthogonality.
        
        For orthogonal M: M^T M = I
        Deviation = ||M^T M - I||_F
        """
        # maps: [batch, d, d] or [num_edges, d, d]
        mtm = torch.bmm(maps.transpose(-2, -1), maps)
        identity = torch.eye(maps.size(-1), device=maps.device).unsqueeze(0)
        identity = identity.expand_as(mtm)
        
        deviation = torch.norm(mtm - identity, p='fro', dim=(-2, -1))
        return deviation.mean()
    
    @staticmethod
    def singular_value_analysis(maps: torch.Tensor) -> Dict[str, float]:
        """
        Analyze singular values of transport maps.
        
        Orthogonal maps have all singular values = 1
        """
        maps_np = maps.detach().cpu().numpy()
        
        all_svs = []
        for M in maps_np:
            _, S, _ = np.linalg.svd(M)
            all_svs.append(S)
        
        all_svs = np.array(all_svs)
        
        return {
            'sv_mean': np.mean(all_svs),
            'sv_std': np.std(all_svs),
            'sv_deviation_from_1': np.mean(np.abs(all_svs - 1.0)),
            'sv_max': np.max(all_svs),
            'sv_min': np.min(all_svs),
            'condition_number': np.mean(all_svs.max(axis=1) / (all_svs.min(axis=1) + 1e-6))
        }
    
    @staticmethod
    def rotation_angle_analysis(maps: torch.Tensor) -> Dict[str, float]:
        """
        Analyze rotation angles in 2D projections of transport maps.
        
        Large rotation angles suggest non-harmonic transport.
        """
        maps_np = maps.detach().cpu().numpy()
        
        angles = []
        for M in maps_np:
            # Project to 2D if needed
            M_2d = M[:2, :2] if M.shape[0] >= 2 else M
            
            # Extract rotation angle from polar decomposition
            U, S, Vh = np.linalg.svd(M_2d)
            R = U @ Vh  # Rotation part
            
            # Angle from rotation matrix
            angle = np.arctan2(R[1, 0], R[0, 0])
            angles.append(np.abs(angle))
        
        angles = np.array(angles)
        
        return {
            'mean_rotation': np.mean(angles),
            'max_rotation': np.max(angles),
            'rotation_std': np.std(angles),
            'rotation_in_degrees': np.mean(angles) * 180 / np.pi
        }
    
    @staticmethod
    def dirichlet_energy(
        node_features: torch.Tensor,
        edge_index: torch.Tensor,
        maps: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Compute Dirichlet energy (smoothness measure).
        
        E_D = Σ_{e=(u,v)} ||F_u x_u - F_v x_v||²
        
        Low energy = smooth/harmonic signal
        High energy = high-frequency/non-harmonic
        """
        row, col = edge_index
        
        if maps is not None:
            # Apply transport maps
            x_u = torch.bmm(maps, node_features[row].unsqueeze(-1)).squeeze(-1)
            x_v = torch.bmm(maps, node_features[col].unsqueeze(-1)).squeeze(-1)
        else:
            x_u = node_features[row]
            x_v = node_features[col]
        
        diff = x_u - x_v
        energy = (diff ** 2).sum(dim=-1).mean()
        
        return energy


class SynchronizationMetrics:
    """
    Metrics inspired by synchronization theory (Kuramoto model).
    """
    
    @staticmethod
    def order_parameter(phases: torch.Tensor) -> torch.Tensor:
        """
        Kuramoto order parameter: r = |1/N Σ exp(i θ_j)|
        
        r → 1: full synchronization
        r → 0: incoherence
        """
        z = torch.exp(1j * phases.to(torch.complex64))
        r = torch.abs(z.mean())
        return r
    
    @staticmethod
    def local_order_parameter(
        phases: torch.Tensor,
        edge_index: torch.Tensor
    ) -> torch.Tensor:
        """
        Local order parameter: average coherence with neighbors.
        """
        row, col = edge_index
        
        z = torch.exp(1j * phases.to(torch.complex64))
        
        # Average phase difference with neighbors
        local_coherence = torch.zeros(phases.size(0), dtype=torch.float32, device=phases.device)
        counts = torch.zeros(phases.size(0), dtype=torch.float32, device=phases.device)
        
        z_diff = z[row] * torch.conj(z[col])
        coherence = torch.abs(z_diff).float()
        
        local_coherence.scatter_add_(0, row, coherence)
        counts.scatter_add_(0, row, torch.ones_like(coherence))
        
        local_r = local_coherence / (counts + 1e-6)
        return local_r.mean()
    
    @staticmethod
    def metastability_index(
        trajectory: List[torch.Tensor],
        window_size: int = 10
    ) -> float:
        """
        Measure metastability: stable intermediate states before convergence.
        
        High metastability = system gets "stuck" in polarized states
        """
        # Compute order parameter over time
        order_params = []
        for state in trajectory:
            if torch.is_tensor(state):
                # Treat first dim as "phase-like"
                phases = state[:, 0] if len(state.shape) > 1 else state
                r = SynchronizationMetrics.order_parameter(phases)
                order_params.append(r.item())
        
        order_params = np.array(order_params)
        
        # Detect metastable plateaus
        # (periods where order parameter is stable but not at equilibrium)
        if len(order_params) < window_size * 2:
            return 0.0
        
        # Rolling variance
        variances = []
        for i in range(len(order_params) - window_size):
            window = order_params[i:i + window_size]
            variances.append(np.var(window))
        
        variances = np.array(variances)
        
        # Metastability = periods of low variance at intermediate r values
        low_var_mask = variances < np.median(variances)
        intermediate_r_mask = (order_params[:-window_size] > 0.2) & (order_params[:-window_size] < 0.8)
        
        metastability = np.mean(low_var_mask & intermediate_r_mask)
        
        return metastability


class TopologicalMetrics:
    """
    Topological metrics inspired by sheaf theory.
    """
    
    @staticmethod
    def sheaf_cohomology_dimension(
        node_features: torch.Tensor,
        edge_index: torch.Tensor,
        maps_source: torch.Tensor,
        maps_target: torch.Tensor
    ) -> Dict[str, float]:
        """
        Approximate sheaf cohomology dimensions.
        
        H⁰: global sections (consensus states)
        H¹: obstructions to extending local sections (polarization barriers)
        """
        num_nodes = node_features.size(0)
        num_edges = edge_index.size(1)
        stalk_dim = node_features.size(1)
        
        # Build coboundary operator δ⁰: C⁰ → C¹
        # δ⁰(s)_e = F_source(s_source) - F_target(s_target)
        
        row, col = edge_index
        
        # Apply transport maps
        x_source = torch.bmm(maps_source, node_features[row].unsqueeze(-1)).squeeze(-1)
        x_target = torch.bmm(maps_target, node_features[col].unsqueeze(-1)).squeeze(-1)
        
        # Coboundary
        coboundary = x_source - x_target  # [num_edges, stalk_dim]
        
        # H⁰ ≈ kernel of δ⁰ (states that transport consistently)
        # Approximate by looking at how well features transport
        transport_error = torch.norm(coboundary, dim=-1).mean()
        
        # H¹ dimension is harder to compute exactly
        # Approximate by rank deficiency of coboundary matrix
        cob_matrix = coboundary.view(-1, stalk_dim)
        
        # Use SVD to estimate rank
        try:
            U, S, V = torch.linalg.svd(cob_matrix, full_matrices=False)
            rank = (S > 0.01 * S.max()).sum().item()
            nullity = stalk_dim - rank
        except:
            rank = stalk_dim
            nullity = 0
        
        return {
            'transport_error': transport_error.item(),
            'coboundary_rank': rank,
            'h0_approx': nullity,  # Larger = more consensus modes
            'h1_approx': num_edges * stalk_dim - rank  # Larger = more obstructions
        }
    
    @staticmethod
    def euler_characteristic_estimate(
        num_nodes: int,
        num_edges: int,
        h0_dim: float,
        h1_dim: float
    ) -> float:
        """
        Estimate Euler characteristic of the graph with sheaf.
        
        χ = dim(H⁰) - dim(H¹)
        
        Negative χ suggests "holes" in the opinion space (polarization barriers)
        """
        return h0_dim - h1_dim


def compute_all_metrics(
    opinions: torch.Tensor,
    edge_index: torch.Tensor,
    transport_maps: Optional[torch.Tensor] = None,
    trajectory: Optional[List[torch.Tensor]] = None
) -> Dict[str, float]:
    """
    Compute all metrics for a given graph state.
    """
    metrics = {}
    
    # Polarization metrics
    pol = PolarizationMetrics()
    metrics['variance_polarization'] = pol.variance_polarization(opinions).item()
    metrics['bimodality_coefficient'] = pol.bimodality_coefficient(opinions)
    
    cluster_metrics = pol.cluster_polarization(opinions)
    metrics.update({f'cluster_{k}': v for k, v in cluster_metrics.items()})
    
    edge_metrics = pol.edge_disagreement(opinions, edge_index)
    metrics.update({f'edge_{k}': v for k, v in edge_metrics.items()})
    
    # Harmonicity metrics (if maps available)
    if transport_maps is not None:
        harm = HarmonicityMetrics()
        metrics['orthogonality_deviation'] = harm.orthogonality_deviation(transport_maps).item()
        
        sv_metrics = harm.singular_value_analysis(transport_maps)
        metrics.update({f'sv_{k}': v for k, v in sv_metrics.items()})
        
        rot_metrics = harm.rotation_angle_analysis(transport_maps)
        metrics.update({f'rotation_{k}': v for k, v in rot_metrics.items()})
        
        metrics['dirichlet_energy'] = harm.dirichlet_energy(
            opinions, edge_index, transport_maps
        ).item()
    
    # Synchronization metrics
    sync = SynchronizationMetrics()
    phases = opinions[:, 0] if len(opinions.shape) > 1 else opinions
    metrics['order_parameter'] = sync.order_parameter(phases).item()
    metrics['local_order_parameter'] = sync.local_order_parameter(phases, edge_index).item()
    
    if trajectory is not None:
        metrics['metastability'] = sync.metastability_index(trajectory)
    
    return metrics


if __name__ == "__main__":
    print("Testing metrics...")
    
    # Create test data
    num_nodes = 100
    opinions = torch.randn(num_nodes, 8)
    edge_index = torch.randint(0, num_nodes, (2, 500))
    maps = torch.randn(500, 8, 8)  # Random transport maps
    
    # Compute metrics
    metrics = compute_all_metrics(opinions, edge_index, maps)
    
    print("\nComputed metrics:")
    for k, v in sorted(metrics.items()):
        print(f"  {k}: {v:.4f}")
    
    print("\n✓ All metric tests passed!")
