"""
Data Loaders for Topological Traps Research
============================================

Supports:
1. Fedivertex (Kaggle) - Real Fediverse graphs
2. Synthetic Opinion Dynamics - Controlled experiments
3. FediverseSharing (when available) - Threads vs Mastodon

Author: Antonio García
"""

import torch
import numpy as np
import networkx as nx
from torch_geometric.data import Data, Dataset, InMemoryDataset
from torch_geometric.utils import from_networkx, to_undirected
from typing import Optional, Tuple, List, Dict, Callable
import os
import json
import pickle
from pathlib import Path
import urllib.request
import zipfile


# ============================================================================
# Synthetic Opinion Dynamics Generator
# ============================================================================

class SyntheticOpinionGenerator:
    """
    Generate synthetic opinion dynamics graphs with controlled polarization.
    
    Models two scenarios:
    1. Organic: Opinions evolve via bounded confidence (Deffuant model)
    2. Algorithmic: Opinions pushed toward extremes by "engagement" algorithm
    """
    
    def __init__(self, seed: int = 42):
        self.rng = np.random.RandomState(seed)
        torch.manual_seed(seed)
    
    def generate_social_graph(
        self,
        num_nodes: int = 1000,
        graph_type: str = 'barabasi_albert',
        **kwargs
    ) -> nx.Graph:
        """
        Generate social network topology.
        """
        if graph_type == 'barabasi_albert':
            m = kwargs.get('m', 5)
            G = nx.barabasi_albert_graph(num_nodes, m, seed=self.rng.randint(1e6))
        elif graph_type == 'watts_strogatz':
            k = kwargs.get('k', 10)
            p = kwargs.get('p', 0.1)
            G = nx.watts_strogatz_graph(num_nodes, k, p, seed=self.rng.randint(1e6))
        elif graph_type == 'stochastic_block':
            # Two communities (for polarization studies)
            sizes = kwargs.get('sizes', [num_nodes // 2, num_nodes // 2])
            p_in = kwargs.get('p_in', 0.1)
            p_out = kwargs.get('p_out', 0.01)
            probs = [[p_in, p_out], [p_out, p_in]]
            G = nx.stochastic_block_model(sizes, probs, seed=self.rng.randint(1e6))
        elif graph_type == 'erdos_renyi':
            p = kwargs.get('p', 0.01)
            G = nx.erdos_renyi_graph(num_nodes, p, seed=self.rng.randint(1e6))
        else:
            raise ValueError(f"Unknown graph type: {graph_type}")
        
        return G
    
    def initialize_opinions(
        self,
        num_nodes: int,
        opinion_dim: int = 1,
        init_type: str = 'uniform',
        **kwargs
    ) -> np.ndarray:
        """
        Initialize node opinions.
        """
        if init_type == 'uniform':
            opinions = self.rng.uniform(-1, 1, (num_nodes, opinion_dim))
        elif init_type == 'bimodal':
            # Two clusters of opinions
            cluster = self.rng.binomial(1, 0.5, num_nodes)
            opinions = np.zeros((num_nodes, opinion_dim))
            opinions[cluster == 0] = self.rng.normal(-0.7, 0.2, (cluster == 0).sum()).reshape(-1, 1)
            opinions[cluster == 1] = self.rng.normal(0.7, 0.2, (cluster == 1).sum()).reshape(-1, 1)
        elif init_type == 'gaussian':
            opinions = self.rng.normal(0, 0.5, (num_nodes, opinion_dim))
        else:
            raise ValueError(f"Unknown init type: {init_type}")
        
        return np.clip(opinions, -1, 1)
    
    def simulate_organic_dynamics(
        self,
        G: nx.Graph,
        opinions: np.ndarray,
        num_steps: int = 100,
        confidence_threshold: float = 0.5,
        convergence_rate: float = 0.1
    ) -> List[np.ndarray]:
        """
        Simulate organic opinion dynamics (Deffuant bounded confidence model).
        
        Agents only interact if their opinions are within a confidence threshold.
        This naturally leads to CONSENSUS or FEW CLUSTERS, not extreme polarization.
        """
        trajectory = [opinions.copy()]
        edges = list(G.edges())
        
        for _ in range(num_steps):
            # Random edge interaction
            i, j = edges[self.rng.randint(len(edges))]
            
            # Bounded confidence: only interact if close enough
            diff = np.abs(opinions[i] - opinions[j])
            if diff.max() < confidence_threshold:
                # Move toward each other
                opinions[i] += convergence_rate * (opinions[j] - opinions[i])
                opinions[j] += convergence_rate * (opinions[i] - opinions[j])
                opinions = np.clip(opinions, -1, 1)
            
            if _ % (num_steps // 20) == 0:
                trajectory.append(opinions.copy())
        
        trajectory.append(opinions.copy())
        return trajectory
    
    def simulate_algorithmic_dynamics(
        self,
        G: nx.Graph,
        opinions: np.ndarray,
        num_steps: int = 100,
        engagement_bias: float = 0.3,
        echo_chamber_strength: float = 0.5,
        controversy_boost: float = 0.2
    ) -> List[np.ndarray]:
        """
        Simulate algorithmic opinion dynamics (engagement-optimized).
        
        Key mechanisms:
        1. Echo chambers: algorithm shows you content from similar opinions
        2. Controversy boost: extreme content gets more visibility
        3. Outgroup exposure: occasional exposure to opposing views INCREASES polarization
        """
        trajectory = [opinions.copy()]
        nodes = list(G.nodes())
        
        for step in range(num_steps):
            for i in nodes:
                neighbors = list(G.neighbors(i))
                if not neighbors:
                    continue
                
                # Algorithm selects which neighbor to show
                neighbor_opinions = opinions[neighbors]
                my_opinion = opinions[i]
                
                # Echo chamber: prefer similar opinions
                similarity = 1 - np.abs(neighbor_opinions - my_opinion).mean(axis=1)
                
                # Controversy boost: also show extreme content
                extremity = np.abs(neighbor_opinions).mean(axis=1)
                
                # Combined algorithmic score
                algo_score = echo_chamber_strength * similarity + controversy_boost * extremity
                algo_score = algo_score / algo_score.sum()
                
                # Sample neighbor according to algorithm
                selected_idx = self.rng.choice(len(neighbors), p=algo_score)
                selected_neighbor = neighbors[selected_idx]
                
                # Update opinion (with engagement bias toward extremes)
                update = engagement_bias * (opinions[selected_neighbor] - my_opinion)
                
                # Bias toward maintaining/increasing extremity
                if np.abs(opinions[i] + update) > np.abs(opinions[i]):
                    opinions[i] += update * 1.2  # Amplify polarizing updates
                else:
                    opinions[i] += update * 0.5  # Dampen consensus updates
                
                opinions[i] = np.clip(opinions[i], -1, 1)
            
            if step % (num_steps // 20) == 0:
                trajectory.append(opinions.copy())
        
        trajectory.append(opinions.copy())
        return trajectory
    
    def generate_dataset(
        self,
        num_graphs: int = 100,
        num_nodes: int = 500,
        scenario: str = 'organic',
        opinion_dim: int = 8,
        num_simulation_steps: int = 200,
        graph_type: str = 'barabasi_albert',
        **kwargs
    ) -> List[Data]:
        """
        Generate a dataset of graphs with simulated opinion dynamics.
        """
        dataset = []
        
        for i in range(num_graphs):
            # Generate graph
            G = self.generate_social_graph(num_nodes, graph_type, **kwargs)
            
            # Initialize opinions
            init_type = 'bimodal' if scenario == 'algorithmic' else 'uniform'
            opinions = self.initialize_opinions(num_nodes, opinion_dim, init_type)
            
            # Simulate dynamics
            if scenario == 'organic':
                trajectory = self.simulate_organic_dynamics(
                    G, opinions, num_simulation_steps,
                    confidence_threshold=kwargs.get('confidence_threshold', 0.5)
                )
            else:
                trajectory = self.simulate_algorithmic_dynamics(
                    G, opinions, num_simulation_steps,
                    engagement_bias=kwargs.get('engagement_bias', 0.3),
                    echo_chamber_strength=kwargs.get('echo_chamber_strength', 0.5)
                )
            
            # Convert to PyG Data
            pyg_data = from_networkx(G)
            
            # Add features
            pyg_data.x = torch.tensor(trajectory[0], dtype=torch.float)
            pyg_data.y = torch.tensor(trajectory[-1], dtype=torch.float)
            pyg_data.trajectory = [torch.tensor(t, dtype=torch.float) for t in trajectory]
            
            # Labels: 0 = organic, 1 = algorithmic
            pyg_data.scenario = torch.tensor([0 if scenario == 'organic' else 1])
            
            # Compute ground truth polarization
            final_opinions = trajectory[-1]
            polarization = np.var(final_opinions)
            pyg_data.polarization = torch.tensor([polarization], dtype=torch.float)
            
            dataset.append(pyg_data)
        
        return dataset


# ============================================================================
# Fedivertex Dataset Loader
# ============================================================================

class FedivertexDataset(InMemoryDataset):
    """
    Loader for the Fedivertex dataset from Kaggle.
    
    Contains graphs from:
    - Mastodon (organic, decentralized)
    - Misskey (organic, decentralized)
    - Lemmy (organic, decentralized)
    - Peertube (organic, decentralized)
    - etc.
    
    For comparison with algorithmic platforms, we treat these as "organic" baseline.
    """
    
    KAGGLE_DATASET = "marcdamie/fediverse-graph-dataset"
    
    def __init__(
        self,
        root: str,
        platform: str = 'mastodon',
        graph_type: str = 'federation',
        transform: Optional[Callable] = None,
        pre_transform: Optional[Callable] = None,
        force_reload: bool = False
    ):
        self.platform = platform.lower()
        self.graph_type = graph_type
        super().__init__(root, transform, pre_transform, force_reload=force_reload)
        self.load(self.processed_paths[0])
    
    @property
    def raw_file_names(self) -> List[str]:
        return ['fedivertex_graphs.pkl']
    
    @property
    def processed_file_names(self) -> List[str]:
        return [f'{self.platform}_{self.graph_type}_processed.pt']
    
    def download(self):
        """
        Instructions for downloading Fedivertex from Kaggle.
        """
        print("=" * 60)
        print("Fedivertex Dataset Download Instructions")
        print("=" * 60)
        print(f"\n1. Install kaggle: pip install kaggle")
        print(f"2. Set up Kaggle API credentials (~/.kaggle/kaggle.json)")
        print(f"3. Run: kaggle datasets download -d {self.KAGGLE_DATASET}")
        print(f"4. Extract to: {self.raw_dir}")
        print("\nAlternatively, install the Python package:")
        print("   pip install fedivertex")
        print("=" * 60)
        
        # Create placeholder for manual download
        os.makedirs(self.raw_dir, exist_ok=True)
        
        # Try to use fedivertex package if available
        try:
            import fedivertex
            print("\nFedivertex package found! Downloading data...")
            self._download_via_package()
        except ImportError:
            print("\nCreating synthetic Fediverse-like data for testing...")
            self._create_synthetic_fediverse()
    
    def _download_via_package(self):
        """Download using the fedivertex Python package."""
        import fedivertex as fv
        
        graphs = []
        for date in fv.available_dates(self.platform, self.graph_type):
            try:
                G = fv.get_graph(self.platform, self.graph_type, date)
                graphs.append(G)
            except:
                continue
        
        # Save
        with open(os.path.join(self.raw_dir, self.raw_file_names[0]), 'wb') as f:
            pickle.dump(graphs, f)
    
    def _create_synthetic_fediverse(self):
        """Create synthetic data mimicking Fediverse structure."""
        generator = SyntheticOpinionGenerator(seed=42)
        
        graphs = []
        for i in range(20):  # 20 snapshots
            # Fediverse-like: many small communities loosely connected
            G = nx.connected_caveman_graph(20, 10)  # 20 cliques of 10 nodes
            
            # Add some inter-community edges (federation)
            nodes = list(G.nodes())
            for _ in range(50):
                i, j = np.random.choice(nodes, 2, replace=False)
                if not G.has_edge(i, j):
                    G.add_edge(i, j)
            
            graphs.append(G)
        
        with open(os.path.join(self.raw_dir, self.raw_file_names[0]), 'wb') as f:
            pickle.dump(graphs, f)
    
    def process(self):
        """Process raw graphs into PyG format."""
        raw_path = os.path.join(self.raw_dir, self.raw_file_names[0])
        
        with open(raw_path, 'rb') as f:
            graphs = pickle.load(f)
        
        data_list = []
        for i, G in enumerate(graphs):
            if isinstance(G, nx.Graph):
                data = from_networkx(G)
            else:
                data = G  # Already PyG format
            
            # Add synthetic node features if not present
            if not hasattr(data, 'x') or data.x is None:
                num_nodes = data.num_nodes
                # Features: degree, clustering, pagerank-like
                G_nx = nx.Graph()
                G_nx.add_edges_from(data.edge_index.t().numpy())
                
                degrees = np.array([G_nx.degree(n) for n in range(num_nodes)])
                clustering = np.array([nx.clustering(G_nx, n) for n in range(num_nodes)])
                
                # Synthetic "opinion" features
                opinions = np.random.randn(num_nodes, 8) * 0.5
                
                features = np.column_stack([
                    degrees / degrees.max(),
                    clustering,
                    opinions
                ])
                data.x = torch.tensor(features, dtype=torch.float)
            
            # Label as organic (Fediverse)
            data.scenario = torch.tensor([0])  # 0 = organic
            data.snapshot_id = torch.tensor([i])
            
            data_list.append(data)
        
        self.save(data_list, self.processed_paths[0])


# ============================================================================
# FediverseSharing Dataset Loader (Threads vs Mastodon)
# ============================================================================

class FediverseSharingDataset(InMemoryDataset):
    """
    Loader for FediverseSharing dataset (when available).
    
    This is the ideal dataset for the paper as it directly compares:
    - Mastodon users (organic, decentralized)
    - Threads users (algorithmic, centralized)
    
    Currently pending publication, so we provide a synthetic version.
    """
    
    def __init__(
        self,
        root: str,
        split: str = 'train',
        transform: Optional[Callable] = None,
        pre_transform: Optional[Callable] = None,
        force_reload: bool = False
    ):
        self.split = split
        super().__init__(root, transform, pre_transform, force_reload=force_reload)
        self.load(self.processed_paths[0])
    
    @property
    def raw_file_names(self) -> List[str]:
        return ['fediversesharing_data.pkl']
    
    @property
    def processed_file_names(self) -> List[str]:
        return [f'fediversesharing_{self.split}.pt']
    
    def download(self):
        """Create synthetic FediverseSharing-like data."""
        print("=" * 60)
        print("FediverseSharing Dataset")
        print("=" * 60)
        print("\nThe official dataset is pending publication.")
        print("Paper: arXiv:2502.17926")
        print("Contact: Ujun Jeong (Arizona State University)")
        print("\nCreating synthetic cross-platform data for testing...")
        print("=" * 60)
        
        os.makedirs(self.raw_dir, exist_ok=True)
        self._create_synthetic_crossplatform()
    
    def _create_synthetic_crossplatform(self):
        """
        Create synthetic data mimicking Threads-Mastodon interactions.
        """
        generator = SyntheticOpinionGenerator(seed=123)
        
        data = {
            'mastodon_graphs': [],
            'threads_graphs': [],
            'cross_platform_edges': []
        }
        
        num_snapshots = 10
        
        for t in range(num_snapshots):
            # Mastodon subgraph: organic dynamics
            G_mastodon = generator.generate_social_graph(
                num_nodes=500,
                graph_type='stochastic_block',
                sizes=[250, 250],
                p_in=0.05,
                p_out=0.005
            )
            opinions_m = generator.initialize_opinions(500, 8, 'uniform')
            traj_m = generator.simulate_organic_dynamics(G_mastodon, opinions_m, 100)
            
            # Threads subgraph: algorithmic dynamics
            G_threads = generator.generate_social_graph(
                num_nodes=500,
                graph_type='barabasi_albert',
                m=10  # More connected (algorithm promotes popular content)
            )
            opinions_t = generator.initialize_opinions(500, 8, 'bimodal')
            traj_t = generator.simulate_algorithmic_dynamics(G_threads, opinions_t, 100)
            
            # Cross-platform edges (federation)
            cross_edges = []
            for _ in range(100):  # 100 cross-platform connections
                m_node = np.random.randint(500)
                t_node = np.random.randint(500)
                cross_edges.append((m_node, t_node + 500))  # Offset Threads nodes
            
            data['mastodon_graphs'].append({
                'graph': G_mastodon,
                'trajectory': traj_m
            })
            data['threads_graphs'].append({
                'graph': G_threads,
                'trajectory': traj_t
            })
            data['cross_platform_edges'].append(cross_edges)
        
        with open(os.path.join(self.raw_dir, self.raw_file_names[0]), 'wb') as f:
            pickle.dump(data, f)
    
    def process(self):
        """Process into PyG format."""
        raw_path = os.path.join(self.raw_dir, self.raw_file_names[0])
        
        with open(raw_path, 'rb') as f:
            data = pickle.load(f)
        
        data_list = []
        
        for t in range(len(data['mastodon_graphs'])):
            # Mastodon graph
            G_m = data['mastodon_graphs'][t]['graph']
            traj_m = data['mastodon_graphs'][t]['trajectory']
            
            pyg_m = from_networkx(G_m)
            pyg_m.x = torch.tensor(traj_m[0], dtype=torch.float)
            pyg_m.y = torch.tensor(traj_m[-1], dtype=torch.float)
            pyg_m.scenario = torch.tensor([0])  # Organic
            pyg_m.platform = 'mastodon'
            pyg_m.snapshot = t
            data_list.append(pyg_m)
            
            # Threads graph
            G_t = data['threads_graphs'][t]['graph']
            traj_t = data['threads_graphs'][t]['trajectory']
            
            pyg_t = from_networkx(G_t)
            pyg_t.x = torch.tensor(traj_t[0], dtype=torch.float)
            pyg_t.y = torch.tensor(traj_t[-1], dtype=torch.float)
            pyg_t.scenario = torch.tensor([1])  # Algorithmic
            pyg_t.platform = 'threads'
            pyg_t.snapshot = t
            data_list.append(pyg_t)
        
        # Split
        n = len(data_list)
        if self.split == 'train':
            data_list = data_list[:int(0.7 * n)]
        elif self.split == 'val':
            data_list = data_list[int(0.7 * n):int(0.85 * n)]
        else:  # test
            data_list = data_list[int(0.85 * n):]
        
        self.save(data_list, self.processed_paths[0])


# ============================================================================
# Utility functions
# ============================================================================

def create_dataloaders(
    dataset_name: str = 'synthetic',
    batch_size: int = 32,
    root: str = './data',
    **kwargs
) -> Tuple:
    """
    Create train/val/test dataloaders.
    """
    from torch_geometric.loader import DataLoader
    
    if dataset_name == 'synthetic':
        generator = SyntheticOpinionGenerator(seed=42)
        
        # Generate organic and algorithmic datasets
        organic_data = generator.generate_dataset(
            num_graphs=100, scenario='organic', **kwargs
        )
        algo_data = generator.generate_dataset(
            num_graphs=100, scenario='algorithmic', **kwargs
        )
        
        # Combine and shuffle
        all_data = organic_data + algo_data
        np.random.shuffle(all_data)
        
        # Split
        n = len(all_data)
        train_data = all_data[:int(0.7 * n)]
        val_data = all_data[int(0.7 * n):int(0.85 * n)]
        test_data = all_data[int(0.85 * n):]
        
    elif dataset_name == 'fedivertex':
        train_data = FedivertexDataset(root, platform='mastodon')
        val_data = train_data  # Use same for now
        test_data = train_data
        
    elif dataset_name == 'fediversesharing':
        train_data = FediverseSharingDataset(root, split='train')
        val_data = FediverseSharingDataset(root, split='val')
        test_data = FediverseSharingDataset(root, split='test')
    
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False)
    
    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    print("Testing data generators...")
    
    # Test synthetic generator
    generator = SyntheticOpinionGenerator(seed=42)
    
    # Generate graphs
    G = generator.generate_social_graph(100, 'barabasi_albert')
    print(f"Generated graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    
    # Initialize opinions
    opinions = generator.initialize_opinions(100, 8, 'bimodal')
    print(f"Opinion shape: {opinions.shape}")
    
    # Simulate organic
    traj_organic = generator.simulate_organic_dynamics(G, opinions.copy(), 100)
    print(f"Organic trajectory length: {len(traj_organic)}")
    print(f"Organic final polarization: {np.var(traj_organic[-1]):.4f}")
    
    # Simulate algorithmic
    traj_algo = generator.simulate_algorithmic_dynamics(G, opinions.copy(), 100)
    print(f"Algorithmic trajectory length: {len(traj_algo)}")
    print(f"Algorithmic final polarization: {np.var(traj_algo[-1]):.4f}")
    
    # Generate dataset
    dataset = generator.generate_dataset(num_graphs=10, num_nodes=100, scenario='organic')
    print(f"\nGenerated dataset with {len(dataset)} graphs")
    print(f"First graph: {dataset[0]}")
    
    print("\n✓ All data tests passed!")
