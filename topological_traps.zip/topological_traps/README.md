# Topological Traps: Neural Sheaf Diffusion for Algorithmic Polarization

![Python](https://img.shields.io/badge/python-3.9+-blue.svg)
![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## Paper

**"Topological Traps: Modeling Algorithmic Polarization via Neural Sheaf Diffusion in Federated Networks"**

### Abstract

Social networks are not simple graphs for information transmission. They are **topological spaces** where recommendation algorithms learn to "twist" connections (Sheaf Transport Maps) to create **metastable polarization states** that, under normal physical models (simple Kuramoto), would collapse into consensus.

### Key Contributions

1. **Dynamic Sheaf Laplacian** $\Delta_{\mathcal{F}}(W_{algo})$ that models algorithmic influence on opinion transport
2. **Topological Traps**: Non-orthogonal transport maps that create stable polarization barriers
3. **Empirical Evidence**: Comparison of organic (Mastodon) vs algorithmic (Threads) platforms

## Mathematical Framework

### Neural Sheaf Diffusion Equation

```
x_{t+1} = x_t - σ(Δ_F(W_algo) · x_t)
```

Where:
- $x_t$ : Node opinions at time $t$
- $\Delta_{\mathcal{F}}$ : Sheaf Laplacian (encodes transport maps)
- $W_{algo}$ : Algorithm weights (learned to maximize engagement)
- $\sigma$ : Nonlinearity (tanh)

### Key Insight

| Platform Type | Transport Maps | Result |
|---------------|----------------|--------|
| **Organic** (Mastodon) | Orthogonal (harmonic) | Consensus |
| **Algorithmic** (Threads) | Rotational (non-harmonic) | Polarization Traps |

## Installation

```bash
# Clone repository
git clone https://github.com/your-repo/topological-traps.git
cd topological-traps

# Create environment
conda create -n sheaf python=3.10
conda activate sheaf

# Install PyTorch (adjust for your CUDA version)
pip install torch torchvision torchaudio

# Install PyTorch Geometric
pip install torch-geometric torch-scatter torch-sparse

# Install other dependencies
pip install -r requirements.txt
```

## Quick Start

### Run Demo
```bash
python main.py --mode demo
```

### Full Training
```bash
python main.py --mode train --num_epochs 100 --num_nodes 500
```

### Generate Figures
```bash
python main.py --mode visualize
```

### Test Models
```bash
python main.py --mode test
```

## Project Structure

```
topological_traps/
├── main.py                 # Entry point
├── requirements.txt        # Dependencies
├── models/
│   └── neural_sheaf_diffusion.py   # Core NSD models
├── data/
│   └── data_loaders.py     # Dataset loaders
├── experiments/
│   └── train_experiments.py # Training code
├── visualizations/
│   └── visualize.py        # Figure generation
└── utils/
    └── metrics.py          # Evaluation metrics
```

## Models

### `NeuralSheafDiffusion`
Base model with dynamic sheaf Laplacian.

### `OrganicSheafDiffusion`
Model for organic platforms with orthogonality regularization.

### `AlgorithmicSheafDiffusion`
Model for algorithmic platforms with multi-head algorithm mixing.

### `KuramotoOscillatorGNN`
Baseline: Standard synchronization model (predicts consensus, not polarization).

## Datasets

### Supported Datasets

1. **Fedivertex** (Recommended)
   - 182 graphs from 7 Fediverse platforms
   - Install: `pip install fedivertex`
   - Or download from [Kaggle](https://www.kaggle.com/datasets/marcdamie/fediverse-graph-dataset)

2. **FediverseSharing** (Threads vs Mastodon)
   - 20k+ users from each platform
   - Status: Pending publication (arXiv:2502.17926)

3. **Synthetic Data** (Default)
   - Controlled opinion dynamics simulation
   - Organic: Bounded confidence model (Deffuant)
   - Algorithmic: Echo chamber + controversy boost

### Using Real Data

```python
from data.data_loaders import FedivertexDataset

# Load Mastodon federation graphs
dataset = FedivertexDataset(
    root='./data',
    platform='mastodon',
    graph_type='federation'
)
```

## Metrics

### Polarization Metrics
- `variance_polarization`: Opinion variance
- `bimodality_coefficient`: BC > 0.555 suggests bimodal (polarized)
- `cluster_polarization`: 2-cluster silhouette score

### Harmonicity Metrics
- `orthogonality_deviation`: ||M^T M - I||_F (lower = more harmonic)
- `singular_value_analysis`: σ ≈ 1 for orthogonal maps
- `rotation_angle_analysis`: Large angles = non-harmonic

### Synchronization Metrics
- `order_parameter`: Kuramoto r ∈ [0,1]
- `metastability_index`: Detection of "trapped" states

## Expected Results

Running full experiments should show:

| Metric | Organic | Algorithmic |
|--------|---------|-------------|
| Harmonicity | ~0.1 (low) | ~0.5 (high) |
| Polarization | ~0.3 | ~0.7 |
| Order Parameter | → 1 (sync) | ~0.5 (trapped) |

**Key Finding**: Algorithmic platforms learn rotational transport maps that create topological barriers to consensus.

## Citation

```bibtex
@article{garcia2026topological,
  title={Topological Traps: Modeling Algorithmic Polarization via 
         Neural Sheaf Diffusion in Federated Networks},
  author={García, Antonio},
  journal={arXiv preprint},
  year={2026}
}
```

## References

1. Bodnar et al. (2022). "Neural Sheaf Diffusion: A Topological Perspective on Heterophily and Oversmoothing in GNNs" (NeurIPS 2022)

2. Jeong et al. (2025). "FediverseSharing: Cross-Platform Interaction Dynamics between Threads and Mastodon Users" (arXiv:2502.17926)

3. Damie & Cyffers (2025). "Fedivertex: A Graph Dataset based on Decentralized Social Networks" (arXiv:2505.20882)

## License

MIT License

## Contact

Antonio García - Cloud AI Network Architect @ Inetum  
[Your PhD research on DRL + Wavelets for Finance]
