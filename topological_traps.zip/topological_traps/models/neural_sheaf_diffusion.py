"""
Neural Sheaf Diffusion with Dynamic Laplacian for Algorithmic Polarization
============================================================================
Paper: "Topological Traps: Modeling Algorithmic Polarization via Neural Sheaf 
        Diffusion in Federated Networks"

Core contribution: Dynamic Sheaf Laplacian Δ_F(W_algo) that models how 
recommendation algorithms "twist" opinion transport maps to create 
metastable polarization states.

Author: Antonio García
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops, degree, softmax
import math
from typing import Optional, Tuple, List


class SheafLaplacianBuilder(nn.Module):
    """
    Constructs the Sheaf Laplacian Δ_F from learned restriction maps.
    
    The key insight is that the sheaf structure encodes how "opinions" 
    transform when transported along edges. In algorithmic platforms,
    these maps can be NON-ORTHOGONAL (rotations that create discord).
    
    Δ_F = Σ_{e=(u,v)} (F_u←e - F_v←e)^T (F_u←e - F_v←e)
    
    where F_u←e : R^d → R^d are the restriction maps.
    """
    
    def __init__(self, stalk_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.stalk_dim = stalk_dim
        self.hidden_dim = hidden_dim
        
        # Network to predict restriction maps from node features
        self.restriction_net = nn.Sequential(
            nn.Linear(2 * stalk_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, stalk_dim * stalk_dim)
        )
        
    def compute_restriction_maps(
        self, 
        x: torch.Tensor, 
        edge_index: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute restriction maps F_{v←e} for each edge endpoint.
        
        Returns: [num_edges, 2, stalk_dim, stalk_dim]
                 The 2 corresponds to source and target restrictions.
        """
        row, col = edge_index
        
        # Concatenate source and target features
        edge_features = torch.cat([x[row], x[col]], dim=-1)
        
        # Predict restriction maps
        maps_flat = self.restriction_net(edge_features)
        maps = maps_flat.view(-1, self.stalk_dim, self.stalk_dim)
        
        # Also compute reverse direction
        edge_features_rev = torch.cat([x[col], x[row]], dim=-1)
        maps_rev_flat = self.restriction_net(edge_features_rev)
        maps_rev = maps_rev_flat.view(-1, self.stalk_dim, self.stalk_dim)
        
        return maps, maps_rev
    
    def compute_connection_laplacian(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        maps_source: torch.Tensor,
        maps_target: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute the sheaf Laplacian applied to node features.
        
        Δ_F x = Σ_e (F_u - F_v)^T (F_u x_u - F_v x_v)
        """
        row, col = edge_index
        num_nodes = x.size(0)
        
        # Apply restriction maps: F_u x_u and F_v x_v
        x_source = torch.bmm(maps_source, x[row].unsqueeze(-1)).squeeze(-1)
        x_target = torch.bmm(maps_target, x[col].unsqueeze(-1)).squeeze(-1)
        
        # Difference in the edge space
        diff = x_source - x_target  # [num_edges, stalk_dim]
        
        # Transport back and aggregate
        # For simplicity, use transpose of source map
        laplacian_contrib = torch.bmm(
            maps_source.transpose(-2, -1), 
            diff.unsqueeze(-1)
        ).squeeze(-1)
        
        # Scatter to nodes
        out = torch.zeros_like(x)
        out.scatter_add_(0, row.unsqueeze(-1).expand_as(laplacian_contrib), laplacian_contrib)
        
        # Subtract contribution from target side
        laplacian_contrib_target = torch.bmm(
            maps_target.transpose(-2, -1),
            diff.unsqueeze(-1)
        ).squeeze(-1)
        out.scatter_add_(0, col.unsqueeze(-1).expand_as(laplacian_contrib_target), -laplacian_contrib_target)
        
        return out


class DynamicSheafLaplacian(nn.Module):
    """
    CORE INNOVATION: Dynamic Sheaf Laplacian that depends on algorithm weights.
    
    Δ_F(t) = Δ_F(W_algo(t))
    
    The algorithm weights W_algo are learned to maximize a proxy for "engagement"
    which we hypothesize correlates with DISCORD (non-harmonic transport).
    """
    
    def __init__(
        self, 
        stalk_dim: int,
        hidden_dim: int = 64,
        num_algo_heads: int = 4,
        dropout: float = 0.1
    ):
        super().__init__()
        self.stalk_dim = stalk_dim
        self.num_heads = num_algo_heads
        
        # Multi-head algorithm weights (like attention but for sheaf transport)
        self.algo_heads = nn.ModuleList([
            SheafLaplacianBuilder(stalk_dim, hidden_dim)
            for _ in range(num_algo_heads)
        ])
        
        # Learnable algorithm mixing weights
        self.algo_mixer = nn.Sequential(
            nn.Linear(stalk_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_algo_heads),
            nn.Softmax(dim=-1)
        )
        
        # Engagement prediction head (for adversarial training)
        self.engagement_head = nn.Sequential(
            nn.Linear(stalk_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
        
    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        return_maps: bool = False
    ) -> Tuple[torch.Tensor, Optional[List[torch.Tensor]]]:
        """
        Compute dynamic sheaf Laplacian weighted by algorithm.
        
        Returns:
            - Laplacian applied to x
            - Optionally, the restriction maps for analysis
        """
        # Get mixing weights based on global graph state
        global_state = x.mean(dim=0)
        mixing_weights = self.algo_mixer(global_state)
        
        # Compute Laplacian from each head
        laplacians = []
        all_maps = []
        
        for i, head in enumerate(self.algo_heads):
            maps_s, maps_t = head.compute_restriction_maps(x, edge_index)
            lap = head.compute_connection_laplacian(x, edge_index, maps_s, maps_t)
            laplacians.append(lap)
            all_maps.append((maps_s, maps_t))
        
        # Mix Laplacians according to algorithm weights
        laplacians = torch.stack(laplacians, dim=0)  # [num_heads, num_nodes, stalk_dim]
        mixed_laplacian = torch.einsum('h,hnd->nd', mixing_weights, laplacians)
        
        if return_maps:
            return mixed_laplacian, all_maps
        return mixed_laplacian, None


class NeuralSheafDiffusion(nn.Module):
    """
    Neural Sheaf Diffusion model with dynamic Laplacian.
    
    The diffusion equation:
        x_{t+1} = x_t - σ(Δ_F(W_algo) x_t)
    
    Key properties:
    - When sheaf is trivial (identity maps): reduces to standard GCN
    - When maps are orthogonal: preserves opinion magnitudes (consensus possible)
    - When maps have rotations: creates "topological traps" (polarization)
    """
    
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int,
        stalk_dim: int = 16,
        num_layers: int = 5,
        num_algo_heads: int = 4,
        diffusion_steps: int = 10,
        step_size: float = 0.1,
        nonlinearity: str = 'tanh',
        dropout: float = 0.1,
        use_dynamic_laplacian: bool = True
    ):
        super().__init__()
        
        self.stalk_dim = stalk_dim
        self.num_layers = num_layers
        self.diffusion_steps = diffusion_steps
        self.step_size = step_size
        self.use_dynamic = use_dynamic_laplacian
        
        # Input projection to stalk space
        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, stalk_dim)
        )
        
        # Dynamic sheaf Laplacian
        if use_dynamic_laplacian:
            self.sheaf_laplacian = DynamicSheafLaplacian(
                stalk_dim, hidden_dim, num_algo_heads, dropout
            )
        else:
            # Static Laplacian (organic/Mastodon scenario)
            self.sheaf_laplacian = SheafLaplacianBuilder(stalk_dim, hidden_dim)
        
        # Nonlinearity
        if nonlinearity == 'tanh':
            self.sigma = nn.Tanh()
        elif nonlinearity == 'relu':
            self.sigma = nn.ReLU()
        else:
            self.sigma = nn.Identity()
        
        # Layer normalization for stability
        self.layer_norms = nn.ModuleList([
            nn.LayerNorm(stalk_dim) for _ in range(diffusion_steps)
        ])
        
        # Output projection
        self.output_proj = nn.Sequential(
            nn.Linear(stalk_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim)
        )
        
        # For analysis: store intermediate states
        self.intermediate_states = []
        
    def diffusion_step(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        step_idx: int
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Single diffusion step: x_{t+1} = x_t - σ(Δ_F x_t)
        """
        if self.use_dynamic:
            laplacian_x, maps = self.sheaf_laplacian(x, edge_index, return_maps=True)
        else:
            maps_s, maps_t = self.sheaf_laplacian.compute_restriction_maps(x, edge_index)
            laplacian_x = self.sheaf_laplacian.compute_connection_laplacian(
                x, edge_index, maps_s, maps_t
            )
            maps = [(maps_s, maps_t)]
        
        # Diffusion update
        x_new = x - self.step_size * self.sigma(laplacian_x)
        
        # Layer normalization
        x_new = self.layer_norms[step_idx](x_new)
        
        return x_new, maps
    
    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        return_trajectory: bool = False
    ) -> Tuple[torch.Tensor, Optional[List[torch.Tensor]]]:
        """
        Full forward pass with multiple diffusion steps.
        """
        # Project to stalk space
        h = self.input_proj(x)
        
        trajectory = [h.clone()] if return_trajectory else None
        all_maps = []
        
        # Diffusion iterations
        for t in range(self.diffusion_steps):
            h, maps = self.diffusion_step(h, edge_index, t)
            
            if return_trajectory:
                trajectory.append(h.clone())
            if maps is not None:
                all_maps.append(maps)
        
        # Project to output
        out = self.output_proj(h)
        
        if return_trajectory:
            return out, trajectory, all_maps
        return out, None, all_maps
    
    def compute_harmonicity_score(
        self,
        maps: List[Tuple[torch.Tensor, torch.Tensor]]
    ) -> torch.Tensor:
        """
        Measure how "harmonic" the learned transport maps are.
        
        Harmonic = orthogonal transforms (preserves magnitudes)
        Non-harmonic = rotations with non-unit determinant (creates discord)
        
        Score close to 1 = harmonic (organic platform behavior)
        Score far from 1 = non-harmonic (algorithmic manipulation)
        """
        scores = []
        
        for maps_s, maps_t in maps:
            # Check orthogonality: M^T M should be close to I
            mtm_s = torch.bmm(maps_s.transpose(-2, -1), maps_s)
            mtm_t = torch.bmm(maps_t.transpose(-2, -1), maps_t)
            
            identity = torch.eye(
                maps_s.size(-1), 
                device=maps_s.device
            ).unsqueeze(0).expand_as(mtm_s)
            
            # Frobenius norm of deviation from identity
            deviation_s = torch.norm(mtm_s - identity, p='fro', dim=(-2, -1))
            deviation_t = torch.norm(mtm_t - identity, p='fro', dim=(-2, -1))
            
            scores.append((deviation_s.mean() + deviation_t.mean()) / 2)
        
        return torch.stack(scores).mean()
    
    def compute_polarization_metric(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute polarization as the variance of opinion differences across edges.
        
        High variance = polarized (opinions diverge along edges)
        Low variance = consensus (opinions similar along edges)
        """
        row, col = edge_index
        
        # Opinion differences along edges
        diffs = h[row] - h[col]
        diff_norms = torch.norm(diffs, dim=-1)
        
        # Polarization = variance of differences
        polarization = diff_norms.var()
        
        return polarization


class OrganicSheafDiffusion(NeuralSheafDiffusion):
    """
    Organic (Mastodon-like) scenario: Static sheaf with tendency toward consensus.
    
    Uses orthogonality regularization to encourage harmonic transport.
    """
    
    def __init__(self, *args, **kwargs):
        kwargs['use_dynamic_laplacian'] = False
        super().__init__(*args, **kwargs)
        
        # Orthogonality regularization weight
        self.ortho_weight = 0.1
    
    def orthogonality_loss(self, maps_s: torch.Tensor, maps_t: torch.Tensor) -> torch.Tensor:
        """
        Regularization to encourage orthogonal (harmonic) transport maps.
        """
        mtm_s = torch.bmm(maps_s.transpose(-2, -1), maps_s)
        mtm_t = torch.bmm(maps_t.transpose(-2, -1), maps_t)
        
        identity = torch.eye(
            maps_s.size(-1), 
            device=maps_s.device
        ).unsqueeze(0).expand_as(mtm_s)
        
        loss = F.mse_loss(mtm_s, identity) + F.mse_loss(mtm_t, identity)
        return loss


class AlgorithmicSheafDiffusion(NeuralSheafDiffusion):
    """
    Algorithmic (Threads-like) scenario: Dynamic sheaf optimized for engagement.
    
    The algorithm learns to maximize "engagement" which we operationalize as
    the DISCORD or non-harmonicity of the transport maps.
    """
    
    def __init__(self, *args, engagement_weight: float = 0.5, **kwargs):
        kwargs['use_dynamic_laplacian'] = True
        super().__init__(*args, **kwargs)
        
        self.engagement_weight = engagement_weight
        
        # Engagement predictor based on graph state
        self.engagement_predictor = nn.Sequential(
            nn.Linear(self.stalk_dim * 2, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
    
    def compute_engagement_proxy(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor
    ) -> torch.Tensor:
        """
        Proxy for engagement: controversy/discord metrics.
        
        Hypothesis: Algorithms maximize engagement by creating controversy,
        which manifests as non-harmonic transport maps.
        """
        row, col = edge_index
        
        # Edge features: concatenate node states
        edge_feats = torch.cat([h[row], h[col]], dim=-1)
        
        # Predict engagement
        engagement = self.engagement_predictor(edge_feats)
        
        return engagement.mean()
    
    def adversarial_engagement_loss(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        maps: List[Tuple[torch.Tensor, torch.Tensor]]
    ) -> torch.Tensor:
        """
        Loss that encourages the algorithm to maximize engagement
        through non-harmonic transport (creating polarization).
        """
        # Engagement proxy
        engagement = self.compute_engagement_proxy(h, edge_index)
        
        # Non-harmonicity (we WANT high values for algorithmic scenario)
        harmonicity = self.compute_harmonicity_score(maps)
        
        # Algorithm wants: high engagement + high non-harmonicity
        # So we minimize: -engagement + harmonicity (during adversarial phase)
        loss = -engagement + 0.1 * harmonicity
        
        return loss


# ============================================================================
# Kuramoto-inspired baseline for comparison
# ============================================================================

class KuramotoOscillatorGNN(nn.Module):
    """
    Kuramoto model on graphs: baseline to show that standard synchronization
    models predict CONSENSUS, not polarization.
    
    dθ_i/dt = ω_i + (K/N) Σ_j A_ij sin(θ_j - θ_i)
    
    This model CANNOT explain stable polarization without external forcing.
    """
    
    def __init__(
        self,
        num_nodes: int,
        coupling_strength: float = 1.0,
        dt: float = 0.01,
        num_steps: int = 100
    ):
        super().__init__()
        
        self.num_nodes = num_nodes
        self.K = coupling_strength
        self.dt = dt
        self.num_steps = num_steps
        
        # Natural frequencies
        self.omega = nn.Parameter(torch.randn(num_nodes) * 0.1)
    
    def forward(
        self,
        theta: torch.Tensor,
        edge_index: torch.Tensor,
        return_trajectory: bool = False
    ) -> Tuple[torch.Tensor, Optional[List[torch.Tensor]]]:
        """
        Simulate Kuramoto dynamics.
        """
        row, col = edge_index
        trajectory = [theta.clone()] if return_trajectory else None
        
        for _ in range(self.num_steps):
            # Coupling term
            phase_diff = theta[col] - theta[row]
            coupling = torch.zeros_like(theta)
            coupling.scatter_add_(0, row, torch.sin(phase_diff))
            
            # Normalize by degree
            deg = degree(row, num_nodes=theta.size(0))
            coupling = coupling / (deg + 1e-6)
            
            # Update
            dtheta = self.omega + self.K * coupling
            theta = theta + self.dt * dtheta
            
            if return_trajectory:
                trajectory.append(theta.clone())
        
        if return_trajectory:
            return theta, trajectory
        return theta, None
    
    def compute_order_parameter(self, theta: torch.Tensor) -> torch.Tensor:
        """
        Kuramoto order parameter r = |1/N Σ exp(i θ_j)|
        
        r → 1: synchronization (consensus)
        r → 0: incoherence
        """
        z = torch.exp(1j * theta.to(torch.complex64))
        r = torch.abs(z.mean())
        return r


if __name__ == "__main__":
    # Quick test
    print("Testing Neural Sheaf Diffusion models...")
    
    # Create dummy data
    num_nodes = 100
    input_dim = 32
    output_dim = 2
    
    x = torch.randn(num_nodes, input_dim)
    edge_index = torch.randint(0, num_nodes, (2, 500))
    
    # Test organic model
    organic = OrganicSheafDiffusion(
        input_dim=input_dim,
        hidden_dim=64,
        output_dim=output_dim,
        stalk_dim=16,
        diffusion_steps=5
    )
    
    out, traj, maps = organic(x, edge_index, return_trajectory=True)
    print(f"Organic output shape: {out.shape}")
    print(f"Trajectory length: {len(traj)}")
    
    # Test algorithmic model
    algo = AlgorithmicSheafDiffusion(
        input_dim=input_dim,
        hidden_dim=64,
        output_dim=output_dim,
        stalk_dim=16,
        diffusion_steps=5
    )
    
    out, traj, maps = algo(x, edge_index, return_trajectory=True)
    print(f"Algorithmic output shape: {out.shape}")
    
    # Compute metrics
    harmonicity = algo.compute_harmonicity_score(maps[-1])
    print(f"Harmonicity score: {harmonicity.item():.4f}")
    
    print("✓ All tests passed!")
