# Topological Traps Package
"""
Neural Sheaf Diffusion for Algorithmic Polarization Analysis
"""

__version__ = "0.1.0"
__author__ = "Antonio García"
